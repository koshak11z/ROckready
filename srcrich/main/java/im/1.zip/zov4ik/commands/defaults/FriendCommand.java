package im.zov4ik.commands.defaults;

import net.minecraft.text.MutableText;
import net.minecraft.text.Text;
import net.minecraft.util.Formatting;



import im.zov4ik.utils.client.managers.api.command.Command;
import im.zov4ik.utils.client.managers.api.command.argument.IArgConsumer;
import im.zov4ik.utils.client.managers.api.command.datatypes.FriendDataType;
import im.zov4ik.utils.client.managers.api.command.datatypes.TabPlayerDataType;
import im.zov4ik.utils.client.managers.api.command.exception.CommandException;
import im.zov4ik.utils.client.managers.api.command.helpers.Paginator;
import im.zov4ik.utils.client.managers.api.command.helpers.TabCompleteHelper;
import im.zov4ik.common.repository.friend.FriendUtils;

import java.util.Arrays;
import java.util.List;
import java.util.Locale;
import java.util.stream.Stream;

import static im.zov4ik.utils.client.managers.api.command.IBaritoneChatControl.FORCE_COMMAND_PREFIX;

public class FriendCommand extends Command {
    protected FriendCommand() {
        super("friend");
    }

    
    @Override
    public void execute(String label, IArgConsumer args) throws CommandException {
        String arg = args.hasAny() ? args.getString().toLowerCase(Locale.US) : "list";
        args.requireMax(1);
        if (arg.contains("add")) {
            String name = args.getString();
            if (!FriendUtils.isFriend(name)) {
                FriendUtils.addFriend(name);
                logDirect("Вы успешно добавили " + name + " в список друзей!");
            } else {
                logDirect(name + " уже есть в списке друзей!", Formatting.RED);
            }
        }
        if (arg.contains("remove")) {
            String name = args.getString();
            if (FriendUtils.isFriend(name)) {
                FriendUtils.removeFriend(name);
                logDirect("Вы успешно удалили " + name + " из списка друзей!");
                return;
            }
            logDirect(name + " не найден в списке друзей", Formatting.RED);
        }
        if (arg.contains("list")) {
            Paginator.paginate(
                    args, new Paginator<>(FriendUtils.getFriends()),
                    () -> logDirect("Список друзей:"),
                    friend -> {
                        String names = friend.getName();
                        MutableText namesComponent = Text.literal(names);
                        namesComponent.setStyle(namesComponent.getStyle().withColor(Formatting.WHITE));
                        return namesComponent;
                    },
                    FORCE_COMMAND_PREFIX + label
            );
        }
        if (arg.contains("clear")) {
            FriendUtils.clear();
            logDirect("Список друзей очищен.");
        }
    }

    @Override
    public Stream<String> tabComplete(String label, IArgConsumer args) throws CommandException {
        if (args.hasAny()) {
            String arg = args.getString();
            if (args.hasExactlyOne()) {
                if (arg.equalsIgnoreCase("add")) {
                    return args.tabCompleteDatatype(TabPlayerDataType.INSTANCE);
                } else if (arg.equalsIgnoreCase("remove")) {
                    return args.tabCompleteDatatype(FriendDataType.INSTANCE);
                }
            } else {
                return new TabCompleteHelper()
                        .sortAlphabetically()
                        .prepend("add", "remove", "list", "clear")
                        .filterPrefix(arg)
                        .stream();
            }
        }
        return Stream.empty();
    }
    
    @Override
    public String getShortDesc() {
        return "Позволяет управлять списком друзей";
    }

    
    @Override
    public List<String> getLongDesc() {
        return Arrays.asList(
                "С помощью этой команды можно добавлять/удалять друзей в чите",
                "",
                "Использование:",
                "> friend add <name> - Добавляет имя в список друзей.",
                "> friend remove <name> - Удаляет имя из списка друзей.",
                "> friend list - Возвращает список друзей",
                "> friend clear - Очищает список друзей."
        );
    }
}
