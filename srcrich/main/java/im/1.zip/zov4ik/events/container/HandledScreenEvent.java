package im.zov4ik.events.container;

import lombok.AccessLevel;
import lombok.AllArgsConstructor;
import lombok.Getter;
import lombok.experimental.FieldDefaults;
import net.minecraft.client.gui.DrawContext;
import net.minecraft.screen.slot.Slot;
import im.zov4ik.utils.client.managers.event.events.Event;
@Getter
@AllArgsConstructor
@FieldDefaults(level = AccessLevel.PRIVATE)
public class HandledScreenEvent implements Event {
    DrawContext drawContext;
    Slot slotHover;
    int mouseX;
    int mouseY;
    int backgroundWidth, backgroundHeight;
}
