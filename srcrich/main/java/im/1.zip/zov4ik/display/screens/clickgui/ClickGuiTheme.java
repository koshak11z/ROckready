package im.zov4ik.display.screens.clickgui;

import im.zov4ik.features.module.ModuleCategory;
import im.zov4ik.utils.display.color.ColorAssist;
import im.zov4ik.features.impl.render.Hud;

public final class ClickGuiTheme {
    public static final int PANEL_BG = 0x8E10141F;
    public static final int PANEL_BG_DARK = 0x82070B12;
    public static final int PANEL_HEADER_BG = 0x97141B2A;
    public static final int PANEL_HEADER_BG_DARK = 0x8C0E1421;
    public static final int PANEL_OUTLINE = 0x7B374563;
    public static final int PANEL_INNER = 0x30080D14;
    public static final int PANEL_INNER_DARK = 0x26060A11;
    public static final int PANEL_DIVIDER = 0x29465D89;
    public static final int ITEM_BG = 0x700B1018;
    public static final int ITEM_BG_HOVER = 0x7D121825;
    public static final int ITEM_BG_ACTIVE = 0x86111928;
    public static final int ITEM_BG_ACTIVE_DARK = 0x7A0D1320;
    public static final int ITEM_OUTLINE = 0x4938455E;
    public static final int SETTINGS_BG = 0x22090D16;
    public static final int SETTINGS_BG_DARK = 0x1A060A11;
    public static final int SEPARATOR = 0x12000000;
    public static final int TEXT_PRIMARY = 0xFFF7FAFF;
    public static final int TEXT_SECONDARY = 0xFFE0E7F3;
    public static final int TEXT_MUTED = 0xFFB7C1D1;
    public static final int CONTROL_BG = 0x56101622;
    public static final int CONTROL_BG_DARK = 0x490B101A;
    public static final int CONTROL_BG_ACTIVE = 0x66131B2A;
    public static final int CONTROL_BG_ACTIVE_DARK = 0x560F1623;
    public static final int CONTROL_OUTLINE = 0x8C384664;
    public static final int TOGGLE_BG = 0xFF0E1522;
    public static final int TOGGLE_KNOB_OFF = 0xFF9DA9BC;
    public static final int TOGGLE_KNOB_ON = 0xFFFDFEFF;
    public static final float CONTROL_WIDTH = 58F;
    public static final float CONTROL_HEIGHT = 14F;
    public static final float CONTROL_MARGIN = 4F;
    public static final float PANEL_RADIUS = 7F;
    public static final float ITEM_RADIUS = 4.8F;
    public static final float CONTROL_RADIUS = 4.1F;
    public static final float HEADER_HEIGHT = 27F;
    public static final float STATE_BADGE_SIZE = 10.8F;
    public static final float TOGGLE_WIDTH = 13F;
    public static final float TOGGLE_HEIGHT = 7F;
    public static final float TOGGLE_KNOB_SIZE = 4.2F;
    public static final int TITLE_FONT_SIZE = 20;
    public static final int MODULE_FONT_SIZE = 17;
    public static final int SETTING_FONT_SIZE = 13;
    public static final int CONTROL_FONT_SIZE = 11;

    private ClickGuiTheme() {
    }

    public static int accent() {
        return 0xFF7C5CFF;
    }

    public static int accentSoft() {
        return ColorAssist.multAlpha(accent(), 0.30F);
    }

    public static int accentGlow() {
        return ColorAssist.multAlpha(accent(), 0.06F);
    }

    public static int accentOutline() {
        return ColorAssist.multAlpha(accent(), 0.82F);
    }

    public static int moduleEnabledFill() {
        return ITEM_BG_ACTIVE;
    }

    public static int moduleEnabledFillBottom() {
        return ITEM_BG_ACTIVE_DARK;
    }

    public static int moduleRowFill(boolean enabled, boolean hovered) {
        return enabled ? ITEM_BG_ACTIVE : (hovered ? ITEM_BG_HOVER : ITEM_BG);
    }

    public static int moduleRowFillBottom(boolean enabled, boolean hovered) {
        return enabled ? ITEM_BG_ACTIVE_DARK : (hovered ? ColorAssist.multDark(ITEM_BG_HOVER, 0.92F) : ColorAssist.multDark(ITEM_BG, 0.9F));
    }

    public static int moduleRowOutline(boolean enabled, boolean hovered) {
        if (enabled) return ColorAssist.overCol(ITEM_OUTLINE, accentSoft(), 0.30F);
        if (hovered) return ColorAssist.overCol(ITEM_OUTLINE, CONTROL_OUTLINE, 0.68F);
        return ITEM_OUTLINE;
    }

    public static int moduleEnabledText() {
        return TEXT_PRIMARY;
    }

    public static int moduleRowFill(float enabledProgress, boolean hovered) {
        int base = hovered ? ITEM_BG_HOVER : ITEM_BG;
        return ColorAssist.overCol(base, ITEM_BG_ACTIVE, enabledProgress);
    }

    public static int moduleRowFillBottom(float enabledProgress, boolean hovered) {
        int base = hovered ? ColorAssist.multDark(ITEM_BG_HOVER, 0.92F) : ColorAssist.multDark(ITEM_BG, 0.9F);
        return ColorAssist.overCol(base, ITEM_BG_ACTIVE_DARK, enabledProgress);
    }

    public static int moduleRowOutline(float enabledProgress, boolean hovered) {
        int base = hovered ? ColorAssist.overCol(ITEM_OUTLINE, CONTROL_OUTLINE, 0.68F) : ITEM_OUTLINE;
        int active = ColorAssist.overCol(ITEM_OUTLINE, accentSoft(), 0.30F);
        return ColorAssist.overCol(base, active, enabledProgress);
    }

    public static int moduleEnabledText(float enabledProgress) {
        return ColorAssist.overCol(TEXT_SECONDARY, TEXT_PRIMARY, enabledProgress);
    }

    public static int settingAccent() {
        return accent();
    }

    public static int categoryAccent(ModuleCategory category) {
        return accent();
    }

    public static int categoryAccentSoft(ModuleCategory category) {
        return ColorAssist.multAlpha(categoryAccent(category), 0.22F);
    }

    public static String panelTitle(ModuleCategory category) {
        return category.getReadableName();
    }

    public static String categoryIcon(ModuleCategory category) {
        return switch (category) {
            case COMBAT -> "A";
            case MOVEMENT -> "B";
            case RENDER -> "C";
            case PLAYER -> "D";
            case MISC -> "E";
            case CONFIGS -> "F";
            case AUTOBUY -> "H";
        };
    }

    public static String iconPath(ModuleCategory category) {
        return switch (category) {
            case RENDER -> "textures/hudicons/visuals.png";
            case MISC -> "textures/hudicons/other.png";
            case CONFIGS, AUTOBUY -> "textures/hudicons/other.png";
            default -> "textures/hudicons/" + category.getReadableName().toLowerCase() + ".png";
        };
    }
}
