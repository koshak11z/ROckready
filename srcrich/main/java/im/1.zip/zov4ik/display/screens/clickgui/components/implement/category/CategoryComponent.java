package im.zov4ik.display.screens.clickgui.components.implement.category;

import im.zov4ik.display.screens.clickgui.ClickGuiTheme;
import im.zov4ik.display.screens.clickgui.MenuScreen;
import im.zov4ik.display.screens.clickgui.components.AbstractComponent;
import im.zov4ik.display.screens.clickgui.components.implement.module.ModuleComponent;
import im.zov4ik.features.module.ModuleCategory;
import im.zov4ik.utils.display.color.ColorAssist;
import im.zov4ik.utils.display.font.Fonts;
import im.zov4ik.utils.display.scissor.ScissorAssist;
import im.zov4ik.utils.display.shape.ShapeProperties;
import im.zov4ik.utils.math.calc.Calculate;
import im.zov4ik.zov4ik;
import lombok.Getter;
import net.minecraft.client.gui.DrawContext;
import net.minecraft.util.math.MathHelper;
import org.joml.Matrix4f;

import java.awt.*;
import java.util.ArrayList;
import java.util.Comparator;
import java.util.List;

@Getter
public class CategoryComponent extends AbstractComponent {
    private final List<ModuleComponent> moduleComponents = new ArrayList<>();
    private final ModuleCategory category;
    private static final int COLUMNS = 3;
    private static final float COLUMN_GAP = 5F;

    public CategoryComponent(ModuleCategory category) {
        this.category = category;
        reloadModules();
    }

    @Override
    public void render(DrawContext context, int mouseX, int mouseY, float delta) {
        validateModuleCache();

        float panelX = Math.round(x);
        float panelY = Math.round(y);
        float panelWidth = Math.round(width);
        float panelHeight = Math.round(height);

        /* — main content background — */
        rectangle.render(ShapeProperties.create(context.getMatrices(), panelX, panelY, panelWidth, panelHeight)
                .round(5.0F)
                .thickness(0.6F)
                .outlineColor(new Color(55, 60, 70, 100).getRGB())
                .color(new Color(14, 16, 22, 200).getRGB())
                .build());

        /* — 3-column layout — */
        float usableWidth = panelWidth - 6F;
        float columnWidth = (usableWidth - COLUMN_GAP * (COLUMNS - 1)) / COLUMNS;
        float contentStartY = panelY + 4F;
        float contentHeight = panelHeight - 8F;

        List<ModuleComponent> visibleModules = getVisibleModules();
        int modulesPerColumn = (int) Math.ceil((double) visibleModules.size() / COLUMNS);

        float maxContentHeight = 0;
        for (int col = 0; col < COLUMNS; col++) {
            float colHeight = 0;
            int startIdx = col * modulesPerColumn;
            int endIdx = Math.min(startIdx + modulesPerColumn, visibleModules.size());
            for (int i = startIdx; i < endIdx; i++) {
                colHeight += visibleModules.get(i).getComponentHeight();
            }
            maxContentHeight = Math.max(maxContentHeight, colHeight);
        }

        scroll = MathHelper.clamp(scroll, -Math.max(0, maxContentHeight - contentHeight), 0);
        smoothedScroll = Calculate.interpolateSmooth(2, (float) smoothedScroll, (float) scroll);

        ScissorAssist scissorManager = zov4ik.getInstance().getScissorManager();
        Matrix4f positionMatrix = context.getMatrices().peek().getPositionMatrix();
        scissorManager.push(positionMatrix, panelX, panelY, panelWidth, panelHeight);

        for (int col = 0; col < COLUMNS; col++) {
            float colX = panelX + 3F + col * (columnWidth + COLUMN_GAP);
            float offsetY = contentStartY + (float) smoothedScroll;
            int startIdx = col * modulesPerColumn;
            int endIdx = Math.min(startIdx + modulesPerColumn, visibleModules.size());

            for (int i = startIdx; i < endIdx; i++) {
                ModuleComponent component = visibleModules.get(i);
                float componentHeight = component.getComponentHeight();
                component.x = colX;
                component.y = offsetY;
                component.width = columnWidth;
                if (offsetY + componentHeight >= contentStartY - 1F && offsetY <= contentStartY + contentHeight + 1F) {
                    component.render(context, mouseX, mouseY, delta);
                }
                offsetY += componentHeight;
            }
        }

        scissorManager.pop();
    }

    @Override
    public boolean mouseClicked(double mouseX, double mouseY, int button) {
        if (!Calculate.isHovered(mouseX, mouseY, x, y, width, height)) {
            return super.mouseClicked(mouseX, mouseY, button);
        }
        for (ModuleComponent component : getVisibleModules()) {
            if (isModuleVisible(component) && component.mouseClicked(mouseX, mouseY, button)) {
                return true;
            }
        }
        return super.mouseClicked(mouseX, mouseY, button);
    }

    @Override
    public boolean mouseReleased(double mouseX, double mouseY, int button) {
        getVisibleModules().forEach(component -> {
            if (isModuleVisible(component)) component.mouseReleased(mouseX, mouseY, button);
        });
        return super.mouseReleased(mouseX, mouseY, button);
    }

    @Override
    public boolean mouseDragged(double mouseX, double mouseY, int button, double deltaX, double deltaY) {
        getVisibleModules().forEach(component -> {
            if (isModuleVisible(component)) component.mouseDragged(mouseX, mouseY, button, deltaX, deltaY);
        });
        return super.mouseDragged(mouseX, mouseY, button, deltaX, deltaY);
    }

    @Override
    public boolean mouseScrolled(double mouseX, double mouseY, double amount) {
        if (Calculate.isHovered(mouseX, mouseY, x, y, width, height)) {
            scroll += amount * 13;
            return true;
        }
        getVisibleModules().forEach(component -> {
            if (isModuleVisible(component)) component.mouseScrolled(mouseX, mouseY, amount);
        });
        return super.mouseScrolled(mouseX, mouseY, amount);
    }

    @Override
    public boolean keyPressed(int keyCode, int scanCode, int modifiers) {
        getVisibleModules().forEach(component -> {
            if (isModuleVisible(component)) component.keyPressed(keyCode, scanCode, modifiers);
        });
        return super.keyPressed(keyCode, scanCode, modifiers);
    }

    @Override
    public boolean charTyped(char chr, int modifiers) {
        getVisibleModules().forEach(component -> {
            if (isModuleVisible(component)) component.charTyped(chr, modifiers);
        });
        return super.charTyped(chr, modifiers);
    }

    private void reloadModules() {
        moduleComponents.clear();
        zov4ik.getInstance().getModuleRepository().modules().stream()
                .filter(module -> module.getCategory() == category)
                .sorted(Comparator.comparing(module -> module.getVisibleName().toLowerCase()))
                .forEach(module -> moduleComponents.add(new ModuleComponent(module)));
    }

    private void validateModuleCache() {
        long actual = zov4ik.getInstance().getModuleRepository().modules().stream()
                .filter(module -> module.getCategory() == category)
                .count();
        if (moduleComponents.size() != actual) {
            reloadModules();
        }
    }

    private List<ModuleComponent> getVisibleModules() {
        return moduleComponents.stream()
                .filter(this::matchesSearch)
                .toList();
    }

    private boolean isModuleVisible(ModuleComponent component) {
        return component.y + component.getComponentHeight() > y && component.y < y + height;
    }

    private boolean matchesSearch(ModuleComponent component) {
        String search = MenuScreen.INSTANCE.getSearchText();
        return search == null || search.isBlank()
                || component.getModule().getName().toLowerCase().contains(search.toLowerCase())
                || component.getModule().getVisibleName().toLowerCase().contains(search.toLowerCase());
    }
}
