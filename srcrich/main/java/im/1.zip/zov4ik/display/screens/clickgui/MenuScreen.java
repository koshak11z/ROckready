package im.zov4ik.display.screens.clickgui;

import im.zov4ik.common.animation.Easy.Direction;
import im.zov4ik.common.animation.Easy.EaseBackIn;
import im.zov4ik.display.screens.clickgui.components.AbstractComponent;
import im.zov4ik.display.screens.clickgui.components.implement.other.CategoryContainerComponent;
import im.zov4ik.display.screens.clickgui.components.implement.other.SearchComponent;
import im.zov4ik.display.screens.clickgui.components.implement.settings.TextComponent;
import im.zov4ik.features.impl.misc.SelfDestruct;
import im.zov4ik.features.module.ModuleCategory;
import im.zov4ik.utils.client.sound.SoundManager;
import im.zov4ik.utils.display.color.ColorAssist;
import im.zov4ik.utils.display.font.FontRenderer;
import im.zov4ik.utils.display.font.Fonts;
import im.zov4ik.utils.display.interfaces.QuickImports;
import im.zov4ik.utils.display.shape.ShapeProperties;
import im.zov4ik.utils.math.calc.Calculate;
import lombok.Getter;
import lombok.Setter;
import net.minecraft.client.gui.DrawContext;
import net.minecraft.client.gui.screen.Screen;
import net.minecraft.client.network.PlayerListEntry;
import net.minecraft.client.util.math.MatrixStack;
import net.minecraft.text.Text;
import net.minecraft.util.Identifier;

import java.awt.*;
import java.util.ArrayList;
import java.util.List;

import static im.zov4ik.common.animation.Easy.Direction.BACKWARDS;
import static im.zov4ik.common.animation.Easy.Direction.FORWARDS;

@Setter
@Getter
public class MenuScreen extends Screen implements QuickImports {
    public static MenuScreen INSTANCE = new MenuScreen();
    private final List<AbstractComponent> components = new ArrayList<>();
    private final CategoryContainerComponent categoryContainerComponent = new CategoryContainerComponent();
    private final SearchComponent searchComponent = new SearchComponent();
    public final EaseBackIn animation = new EaseBackIn(325, 1f, 1.5f);
    public ModuleCategory category = ModuleCategory.COMBAT;
    public int x, y, width, height;

    private static final float TOP_BAR_HEIGHT = 28F;
    private static final ModuleCategory[] CATEGORIES = {
            ModuleCategory.COMBAT, ModuleCategory.MOVEMENT,
            ModuleCategory.RENDER, ModuleCategory.PLAYER, ModuleCategory.MISC
    };

    /* — tab switch animation — */
    private float tabIndicatorX = -1;
    private float tabIndicatorTargetX = -1;
    private float contentAlpha = 1.0F;

    public void initialize() {
        animation.setDirection(FORWARDS);
        categoryContainerComponent.initializeCategoryComponents(category);
        components.clear();
        components.add(categoryContainerComponent);
        components.add(searchComponent);
    }

    public MenuScreen() {
        super(Text.of("MenuScreen"));
        initialize();
    }

    @Override
    public void tick() {
        close();
        components.forEach(AbstractComponent::tick);
        super.tick();
    }

    @Override
    public void render(DrawContext context, int mouseX, int mouseY, float delta) {
        width = Math.min(window.getScaledWidth() - 96, 640);
        height = Math.min(window.getScaledHeight() - 72, 314);
        x = window.getScaledWidth() / 2 - width / 2;
        y = window.getScaledHeight() / 2 - height / 2;

        blur.setup();
        rectangle.render(ShapeProperties.create(context.getMatrices(), 0, 0, window.getScaledWidth(), window.getScaledHeight())
                .color(Calculate.applyOpacity(0xFF05070B, 18 * getScaleAnimation()))
                .build());

        final float contentY = y + TOP_BAR_HEIGHT + 4F;
        final float contentHeight = height - TOP_BAR_HEIGHT - 32F;
        categoryContainerComponent.position(x, contentY).size(width, contentHeight);
        searchComponent.position(x + width / 2F - 55F, y + height - 20F).size(110, 15);

        Calculate.scale(context.getMatrices(), x + (float) width / 2, y + (float) height / 2, getScaleAnimation(), () -> {
            drawTopBar(context, mouseX, mouseY);
            /* — apply fade-in for tab switch animation — */
            if (contentAlpha < 1.0F) {
                context.getMatrices().push();
                float scale = 0.96F + 0.04F * contentAlpha;
                float cx = x + width / 2F;
                float cy = contentY + contentHeight / 2F;
                context.getMatrices().translate(cx, cy, 0);
                context.getMatrices().scale(scale, scale, 1F);
                context.getMatrices().translate(-cx, -cy, 0);
            }
            components.forEach(component -> component.render(context, mouseX, mouseY, delta));
            if (contentAlpha < 1.0F) {
                context.getMatrices().pop();
            }
            windowManager.render(context, mouseX, mouseY, delta);
        });
        super.render(context, mouseX, mouseY, delta);
    }

    private void drawTopBar(DrawContext context, int mouseX, int mouseY) {
        MatrixStack matrix = context.getMatrices();
        FontRenderer catIconFont = Fonts.getSize(17, Fonts.Type.ICONSCATEGORY);

        /* — top bar background — */
        rectangle.render(ShapeProperties.create(matrix, x, y, width, TOP_BAR_HEIGHT)
                .round(5.0F)
                .thickness(0.6F)
                .outlineColor(new Color(55, 60, 70, 110).getRGB())
                .color(new Color(14, 16, 22, 220).getRGB())
                .build());

        /* — "Z" brand letter (left, white) — */
        int accentColor = ClickGuiTheme.accent();
        FontRenderer brandFont = Fonts.getSize(22, Fonts.Type.BOLDED);
        float brandW = brandFont.getStringWidth("Z");
        float brandX = x + 10F;
        float brandY = y + (TOP_BAR_HEIGHT - brandFont.getStringHeight("Z")) / 2F;
        brandFont.drawString(matrix, "Z", brandX, brandY, -1 /* white */);

        /* — category tabs (center) with animated indicator — */
        float tabAreaWidth = CATEGORIES.length * 26F;
        float tabStartX = x + width / 2F - tabAreaWidth / 2F;

        /* compute selected tab center for animation */
        float selectedCenterX = tabStartX + 13F;
        for (int i = 0; i < CATEGORIES.length; i++) {
            if (CATEGORIES[i] == category) {
                selectedCenterX = tabStartX + i * 26F + 13F;
                break;
            }
        }
        if (tabIndicatorX < 0) tabIndicatorX = selectedCenterX;
        tabIndicatorTargetX = selectedCenterX;
        tabIndicatorX += (tabIndicatorTargetX - tabIndicatorX) * 0.22F;
        if (Math.abs(tabIndicatorTargetX - tabIndicatorX) < 0.3F) tabIndicatorX = tabIndicatorTargetX;

        /* content fade-in after tab switch */
        contentAlpha += (1.0F - contentAlpha) * 0.18F;
        if (contentAlpha > 0.99F) contentAlpha = 1.0F;

        for (int i = 0; i < CATEGORIES.length; i++) {
            ModuleCategory cat = CATEGORIES[i];
            String icon = ClickGuiTheme.categoryIcon(cat);
            float tabX = tabStartX + i * 26F;
            float tabCenterX = tabX + 13F;
            boolean isSelected = category == cat;
            boolean isHovered = Calculate.isHovered(mouseX, mouseY, tabX, y, 26F, TOP_BAR_HEIGHT);

            int iconColor;
            if (isSelected) iconColor = accentColor;
            else if (isHovered) iconColor = 0xFFDDE3EF;
            else iconColor = 0xFF808898;

            float iconW = catIconFont.getStringWidth(icon);
            catIconFont.drawString(matrix, icon, tabCenterX - iconW / 2F, y + (TOP_BAR_HEIGHT - 14F) / 2F, iconColor);
        }

        /* — animated underline indicator — */
        rectangle.render(ShapeProperties.create(matrix,
                        tabIndicatorX - 5F, y + TOP_BAR_HEIGHT - 2.5F, 10F, 1.5F)
                .round(0.75F)
                .color(accentColor)
                .build());

        /* — player head (right) — */
        if (mc.player != null) {
            PlayerListEntry entry = mc.getNetworkHandler() != null
                    ? mc.getNetworkHandler().getPlayerListEntry(mc.player.getUuid())
                    : null;
            if (entry != null) {
                Identifier skinTexture = entry.getSkinTextures().texture();
                float headSize = 14F;
                float headX = x + width - headSize - 10F;
                float headY = y + (TOP_BAR_HEIGHT - headSize) / 2F;
                im.zov4ik.utils.display.geometry.Render2D.drawTexture(context, skinTexture,
                        headX, headY, headSize, 4, 8, 8, 64, ColorAssist.getRect(1), -1);
            }
        }
    }

    public void openGui() {
        if (SelfDestruct.unhooked) return;
        animation.setDirection(Direction.FORWARDS);
        animation.reset();
        mc.setScreen(this);
        SoundManager.playSound(SoundManager.OPEN_GUI);
    }

    public float getScaleAnimation() {
        return (float) animation.getOutput();
    }

    public String getSearchText() {
        return searchComponent.getText();
    }

    @Override
    public boolean mouseClicked(double mouseX, double mouseY, int button) {
        /* — top bar category tab clicks — */
        if (button == 0) {
            float tabAreaWidth = CATEGORIES.length * 24F;
            float tabStartX = x + width / 2F - tabAreaWidth / 2F;
            for (int i = 0; i < CATEGORIES.length; i++) {
                float tabX = tabStartX + i * 24F;
                if (Calculate.isHovered(mouseX, mouseY, tabX, y, 24F, TOP_BAR_HEIGHT)) {
                    category = CATEGORIES[i];
                    contentAlpha = 0.0F;
                    categoryContainerComponent.initializeCategoryComponents();
                    return true;
                }
            }
        }

        boolean windowHandled = windowManager.mouseClicked(mouseX, mouseY, button);
        if (!windowHandled) {
            for (AbstractComponent component : components) {
                component.mouseClicked(mouseX, mouseY, button);
            }
        }
        return super.mouseClicked(mouseX, mouseY, button);
    }

    @Override
    public boolean mouseReleased(double mouseX, double mouseY, int button) {
        for (AbstractComponent component : components) {
            component.mouseReleased(mouseX, mouseY, button);
        }
        windowManager.mouseReleased(mouseX, mouseY, button);
        return super.mouseReleased(mouseX, mouseY, button);
    }

    @Override
    public boolean mouseDragged(double mouseX, double mouseY, int button, double deltaX, double deltaY) {
        boolean windowHandled = windowManager.mouseDragged(mouseX, mouseY, button, deltaX, deltaY);
        if (!windowHandled) {
            for (AbstractComponent component : components) {
                component.mouseDragged(mouseX, mouseY, button, deltaX, deltaY);
            }
        }
        return super.mouseDragged(mouseX, mouseY, button, deltaX, deltaY);
    }

    @Override
    public boolean mouseScrolled(double mouseX, double mouseY, double horizontal, double vertical) {
        boolean windowHandled = windowManager.mouseScrolled(mouseX, mouseY, vertical);
        if (!windowHandled) {
            for (AbstractComponent component : components) {
                component.mouseScrolled(mouseX, mouseY, vertical);
            }
        }
        return super.mouseScrolled(mouseX, mouseY, horizontal, vertical);
    }

    @Override
    public boolean keyPressed(int keyCode, int scanCode, int modifiers) {
        if (keyCode == 256 && shouldCloseOnEsc()) {
            SoundManager.playSound(SoundManager.CLOSE_GUI);
            animation.setDirection(BACKWARDS);
            return true;
        }
        if (!windowManager.keyPressed(keyCode, scanCode, modifiers)) {
            for (AbstractComponent component : components) {
                component.keyPressed(keyCode, scanCode, modifiers);
            }
        }
        return super.keyPressed(keyCode, scanCode, modifiers);
    }

    @Override
    public boolean charTyped(char chr, int modifiers) {
        if (!windowManager.charTyped(chr, modifiers)) {
            for (AbstractComponent component : components) {
                component.charTyped(chr, modifiers);
            }
        }
        return super.charTyped(chr, modifiers);
    }

    @Override
    public boolean shouldPause() {
        return false;
    }

    @Override
    public void close() {
        if (animation.finished(BACKWARDS)) {
            TextComponent.typing = false;
            super.close();
        }
    }
}
