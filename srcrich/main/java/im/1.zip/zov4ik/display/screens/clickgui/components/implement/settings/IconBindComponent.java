package im.zov4ik.display.screens.clickgui.components.implement.settings;

import net.minecraft.client.gui.DrawContext;
import net.minecraft.client.util.math.MatrixStack;
import net.minecraft.util.math.ColorHelper;
import org.lwjgl.glfw.GLFW;

import im.zov4ik.features.module.setting.implement.BindSetting;
import im.zov4ik.utils.display.font.Fonts;
import im.zov4ik.utils.display.shape.ShapeProperties;
import im.zov4ik.utils.math.calc.Calculate;
import im.zov4ik.utils.client.chat.StringHelper;

import java.awt.*;

import static im.zov4ik.utils.display.font.Fonts.Type.*;

public class IconBindComponent extends AbstractSettingComponent {
    private final BindSetting setting;
    private boolean binding;

    public IconBindComponent(BindSetting setting) {
        super(setting);
        this.setting = setting;
    }


    @Override
    public void render(DrawContext context, int mouseX, int mouseY, float delta) {
        MatrixStack matrix = context.getMatrices();

        java.lang.String bindName = StringHelper.getBindName(setting.getKey());
        java.lang.String name = binding ? "(" + bindName + ") ..." : bindName;
        float stringWidth = Fonts.getSize(11, SEMI).getStringWidth(name) - 2;

        height = 20;

        rectangle.render(ShapeProperties.create(matrix, x + width - stringWidth - 17, y + 5.5f, stringWidth + 10, 12)
                .round(3f)
                .outlineColor(new Color(200, 200, 200, 255).getRGB())
                .color(
                        new Color(61, 67, 71, 80).getRGB(),
                        new Color(71, 77, 81, 80).getRGB(),
                        new Color(81, 87, 91, 80).getRGB(),
                        new Color(91, 97, 101, 80).getRGB())
                .build());
        int bindingColor = ColorHelper.getArgb(255, 135, 136, 148);

        Fonts.getSize(11, SEMI).drawString(matrix, name, x + width - 12 - stringWidth - 1, y + 11, bindingColor);

        Fonts.getSize(14, GUIICONS).drawString(context.getMatrices(), "L", x + 6, y + 11f, new Color(128, 128, 128, 64).getRGB());

        Fonts.getSize(12, DEFAULT).drawString(context.getMatrices(), setting.getName(), x + 17, y + 10f, 0xFFD4D6E1);
//        Fonts.getSize(12, DEFAULT).drawString(context.getMatrices(), wrapped, x + 9, y + 15, 0xFF878894);
    }


    @Override
    public boolean mouseClicked(double mouseX, double mouseY, int button) {
        if (button == 0) {
            if (Calculate.isHovered(mouseX, mouseY, x, y, width, height)) {
                binding = !binding;
            } else {
                binding = false;
            }
        }

        if (binding && button > 1) {
            setting.setKey(button);
            binding = false;
        }
        return super.mouseClicked(mouseX, mouseY, button);
    }


    @Override
    public boolean keyPressed(int keyCode, int scanCode, int modifiers) {
        int key = keyCode == GLFW.GLFW_KEY_DELETE ? -1 : keyCode;
        if (binding) {
            setting.setKey(key);
            binding = false;
        }

        return super.keyPressed(keyCode, scanCode, modifiers);
    }
}
