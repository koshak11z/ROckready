package im.zov4ik.display.screens.clickgui.components.implement.module;

import lombok.Getter;
import net.minecraft.client.gui.DrawContext;
import org.lwjgl.glfw.GLFW;

import org.joml.Matrix4f;

import im.zov4ik.features.module.Module;
import im.zov4ik.utils.display.font.FontRenderer;
import im.zov4ik.features.module.setting.SettingComponentAdder;
import im.zov4ik.common.animation.Animation;
import im.zov4ik.common.animation.Direction;
import im.zov4ik.common.animation.implement.Decelerate;
import im.zov4ik.utils.display.font.Fonts;
import im.zov4ik.utils.display.shape.ShapeProperties;
import im.zov4ik.utils.display.color.ColorAssist;
import im.zov4ik.utils.math.calc.Calculate;
import im.zov4ik.utils.display.scissor.ScissorAssist;
import im.zov4ik.utils.client.chat.StringHelper;
import im.zov4ik.zov4ik;
import im.zov4ik.display.screens.clickgui.ClickGuiPainter;
import im.zov4ik.display.screens.clickgui.ClickGuiTheme;
import im.zov4ik.display.screens.clickgui.components.AbstractComponent;
import im.zov4ik.display.screens.clickgui.components.implement.settings.AbstractSettingComponent;

import java.awt.*;
import java.util.ArrayList;
import java.util.HashMap;
import java.util.List;
import java.util.Map;
import java.util.Objects;
import java.util.function.Supplier;

@Getter
public class ModuleComponent extends AbstractComponent {
    private static final float ROW_HEIGHT = 20F;
    private static final float TOGGLE_AREA_WIDTH = 22F;

    private final List<AbstractSettingComponent> components = new ArrayList<>();
    private final Module module;
    private boolean expanded;
    private float cachedHeight = 15F;
    private final Animation expandAnimation = new Decelerate().setMs(220).setValue(1);
    private final Map<AbstractSettingComponent, Float> settingVisibility = new HashMap<>();
    private final Map<AbstractSettingComponent, Float> settingHeight = new HashMap<>();
    private boolean binding;
    private float toggleProgress;

    public ModuleComponent(Module module) {
        this.module = module;
        new SettingComponentAdder().addSettingComponent(module.settings(), components);
        this.expanded = false;
        expandAnimation.setDirection(Direction.BACKWARDS);
        for (AbstractSettingComponent component : components) {
            settingVisibility.put(component, 0F);
            settingHeight.put(component, 16F);
        }
        toggleProgress = module.isState() ? 1F : 0F;
    }

    @Override
    public void render(DrawContext context, int mouseX, int mouseY, float delta) {
        float rowHeight = ROW_HEIGHT;
        float toggleX = x + width - TOGGLE_AREA_WIDTH;
        boolean hoveredRow = Calculate.isHovered(mouseX, mouseY, x, y, width, rowHeight);
        expandAnimation.setDirection(expanded ? Direction.FORWARDS : Direction.BACKWARDS);
        float expand = expandAnimation.getOutput().floatValue();
        toggleProgress = Calculate.interpolateSmooth(3.6F, toggleProgress, module.isState() ? 1F : 0F);

        /* — module name (left) — */
        int textColor = module.isState() ? 0xFFFFFFFF : 0xFFB0B8C8;
        if (hoveredRow && !module.isState()) textColor = 0xFFD8DDE8;
        String name = binding ? module.getVisibleName() + " [...]" : module.getVisibleName();

        /* — bind text (before toggle, muted) — */
        String bindText = "";
        if (!binding && module.getKey() > 0) {
            String keyName = GLFW.glfwGetKeyName(module.getKey(), 0);
            bindText = keyName != null ? "[" + keyName.toUpperCase() + "]" : "[" + module.getKey() + "]";
        }

        FontRenderer nameFont = Fonts.getSize(ClickGuiTheme.MODULE_FONT_SIZE, Fonts.Type.BOLD);
        FontRenderer bindFont = Fonts.getSize(11, Fonts.Type.SEMI);
        float bindWidth = bindText.isEmpty() ? 0 : bindFont.getStringWidth(bindText) + 4F;
        float maxNameWidth = width - 8.5F - TOGGLE_AREA_WIDTH - bindWidth - 4F;

        drawModuleName(context, name, y + 7F, textColor, maxNameWidth);

        /* — bind text — */
        if (!bindText.isEmpty()) {
            float bindX = toggleX - bindWidth - 2F;
            bindFont.drawString(context.getMatrices(), bindText, bindX, y + 9F, 0xFF606878);
        }

        /* — toggle switch (right) — */
        float toggleSwitchX = toggleX + 3F;
        float toggleSwitchY = y + (rowHeight - ClickGuiTheme.TOGGLE_HEIGHT) / 2F;
        ClickGuiPainter.drawToggle(context, toggleSwitchX, toggleSwitchY, toggleProgress);

        /* — expanded settings — */
        float offset = y + rowHeight;
        float settingsHeight = getAnimatedSettingsHeight(expand);
        float visibleSettingsHeight = settingsHeight;
        if (visibleSettingsHeight > 0.2F) {
            float innerX = x + 4F;
            float innerW = width - 8F;

            ScissorAssist scissorManager = zov4ik.getInstance().getScissorManager();
            Matrix4f positionMatrix = context.getMatrices().peek().getPositionMatrix();
            scissorManager.push(positionMatrix, innerX, offset, innerW, visibleSettingsHeight);
            for (AbstractSettingComponent component : components) {
                Supplier<Boolean> visible = component.getSetting().getVisible();
                boolean shouldBeVisible = visible == null || visible.get();
                float visibility = settingVisibility.getOrDefault(component, shouldBeVisible ? 1F : 0F) * expand;

                float baseHeight = settingHeight.getOrDefault(component, 16F);
                float elementHeight = baseHeight * visibility;

                component.x = innerX + 1F;
                component.y = offset;
                component.width = innerW - 2F;

                if (elementHeight > 0.4F) {
                    scissorManager.push(positionMatrix, component.x, component.y, component.width, elementHeight);
                    component.render(context, mouseX, mouseY, delta);
                    scissorManager.pop();
                    float measured = Math.max(16F, component.height);
                    settingHeight.put(component, measured);
                    baseHeight = measured;
                    elementHeight = baseHeight * visibility;
                }

                offset += elementHeight;
            }
            scissorManager.pop();
        }

        cachedHeight = rowHeight + settingsHeight;
    }

    @Override
    public boolean mouseClicked(double mouseX, double mouseY, int button) {
        float rowHeight = ROW_HEIGHT;
        float toggleX = x + width - TOGGLE_AREA_WIDTH;
        boolean hoveredRow = Calculate.isHovered(mouseX, mouseY, x, y, width, rowHeight);
        boolean hoveredToggle = Calculate.isHovered(mouseX, mouseY, toggleX, y, TOGGLE_AREA_WIDTH, rowHeight);

        /* middle click — bind mode */
        if (hoveredRow && button == 2) {
            binding = !binding;
            return true;
        }

        if (binding && button >= 2) {
            module.setKey(button);
            binding = false;
            return true;
        }

        /* left-click toggle area — toggle module */
        if (hoveredToggle && button == 0 && !binding) {
            module.switchState();
            return true;
        }

        /* left-click name area — toggle module */
        if (hoveredRow && !hoveredToggle && button == 0 && !binding) {
            module.switchState();
            return true;
        }

        /* right-click row — expand/collapse settings */
        if (hoveredRow && button == 1) {
            expanded = !expanded;
            return true;
        }

        if (expanded || !expandAnimation.isFinished(Direction.BACKWARDS)) {
            for (int i = components.size() - 1; i >= 0; i--) {
                AbstractSettingComponent component = components.get(i);
                if (component.isHover(mouseX, mouseY) && component.mouseClicked(mouseX, mouseY, button)) {
                    return true;
                }
            }
            for (int i = components.size() - 1; i >= 0; i--) {
                if (components.get(i).mouseClicked(mouseX, mouseY, button)) {
                    return true;
                }
            }
        }
        return super.mouseClicked(mouseX, mouseY, button);
    }

    @Override
    public boolean mouseDragged(double mouseX, double mouseY, int button, double deltaX, double deltaY) {
        if (expanded || !expandAnimation.isFinished(Direction.BACKWARDS)) {
            components.forEach(component -> component.mouseDragged(mouseX, mouseY, button, deltaX, deltaY));
        }
        return super.mouseDragged(mouseX, mouseY, button, deltaX, deltaY);
    }

    @Override
    public boolean mouseReleased(double mouseX, double mouseY, int button) {
        if (expanded || !expandAnimation.isFinished(Direction.BACKWARDS)) {
            components.forEach(component -> component.mouseReleased(mouseX, mouseY, button));
        }
        return super.mouseReleased(mouseX, mouseY, button);
    }

    @Override
    public boolean mouseScrolled(double mouseX, double mouseY, double amount) {
        if (expanded || !expandAnimation.isFinished(Direction.BACKWARDS)) {
            components.forEach(component -> component.mouseScrolled(mouseX, mouseY, amount));
        }
        return super.mouseScrolled(mouseX, mouseY, amount);
    }

    @Override
    public boolean keyPressed(int keyCode, int scanCode, int modifiers) {
        if (binding) {
            module.setKey(keyCode == GLFW.GLFW_KEY_DELETE ? -1 : keyCode);
            binding = false;
            return true;
        }
        if (expanded || !expandAnimation.isFinished(Direction.BACKWARDS)) {
            components.forEach(component -> component.keyPressed(keyCode, scanCode, modifiers));
        }
        return super.keyPressed(keyCode, scanCode, modifiers);
    }

    @Override
    public boolean charTyped(char chr, int modifiers) {
        if (expanded || !expandAnimation.isFinished(Direction.BACKWARDS)) {
            components.forEach(component -> component.charTyped(chr, modifiers));
        }
        return super.charTyped(chr, modifiers);
    }

    @Override
    public boolean isHover(double mouseX, double mouseY) {
        if (Calculate.isHovered(mouseX, mouseY, x, y, width, getComponentHeight())) return true;
        if (expanded || !expandAnimation.isFinished(Direction.BACKWARDS)) {
            for (AbstractSettingComponent component : components) {
                if (component.isHover(mouseX, mouseY)) return true;
            }
        }
        return false;
    }

    public int getComponentHeight() {
        return Math.max((int) ROW_HEIGHT, Math.round(cachedHeight));
    }

    private void drawModuleName(DrawContext context, String text, float drawY, int color, float availableWidth) {
        FontRenderer font = Fonts.getSize(ClickGuiTheme.MODULE_FONT_SIZE, Fonts.Type.BOLD);
        float drawX = x + 8.5F;
        availableWidth = Math.max(10F, availableWidth);

        if (font.getStringWidth(text) <= availableWidth) {
            font.drawString(context.getMatrices(), text, drawX, drawY, color);
            return;
        }

        Matrix4f positionMatrix = context.getMatrices().peek().getPositionMatrix();
        ScissorAssist scissorManager = zov4ik.getInstance().getScissorManager();
        scissorManager.push(positionMatrix, drawX, y + 3F, availableWidth, 16F);
        font.drawStringWithScroll(context.getMatrices(), text, drawX, drawY, availableWidth, color);
        scissorManager.pop();
    }

    private float getAnimatedSettingsHeight(float expand) {
        float h = 0F;
        for (AbstractSettingComponent component : components) {
            Supplier<Boolean> visible = component.getSetting().getVisible();
            boolean shouldBeVisible = visible == null || visible.get();
            float target = shouldBeVisible ? 1F : 0F;
            float current = settingVisibility.getOrDefault(component, 0F);
            float smoothed = Calculate.interpolateSmooth(3, current, target);
            settingVisibility.put(component, smoothed);
            h += settingHeight.getOrDefault(component, 16F) * smoothed * expand;
        }
        return h;
    }

    @Override
    public boolean equals(Object o) {
        if (this == o) return true;
        if (o == null || getClass() != o.getClass()) return false;
        ModuleComponent that = (ModuleComponent) o;
        return module.equals(that.module);
    }

    @Override
    public int hashCode() {
        return Objects.hash(module);
    }
}
