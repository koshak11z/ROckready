package im.zov4ik.display.screens.clickgui;

import im.zov4ik.utils.display.color.ColorAssist;
import im.zov4ik.utils.display.font.Fonts;
import im.zov4ik.utils.display.interfaces.QuickImports;
import im.zov4ik.utils.display.shape.ShapeProperties;
import net.minecraft.client.gui.DrawContext;
import net.minecraft.util.math.MathHelper;

import java.awt.*;

public final class ClickGuiPainter {
    private ClickGuiPainter() {
    }

    public static void drawControlSurface(DrawContext context, float x, float y, float width, float height, boolean active) {
        drawControlSurface(context, x, y, width, height, ClickGuiTheme.CONTROL_RADIUS, active ? 1F : 0F);
    }

    public static void drawControlSurface(DrawContext context, float x, float y, float width, float height, float radius, boolean active) {
        drawControlSurface(context, x, y, width, height, radius, active ? 1F : 0F);
    }

    public static void drawControlSurface(DrawContext context, float x, float y, float width, float height, float activeProgress) {
        drawControlSurface(context, x, y, width, height, ClickGuiTheme.CONTROL_RADIUS, activeProgress);
    }

    public static void drawControlSurface(DrawContext context, float x, float y, float width, float height, float radius, float activeProgress) {
        float progress = MathHelper.clamp(activeProgress, 0F, 1F);
        int outlineIdle = ClickGuiTheme.CONTROL_OUTLINE;
        int outlineActive = ColorAssist.overCol(ClickGuiTheme.CONTROL_OUTLINE, ClickGuiTheme.accentSoft(), 0.32F);
        int outline = ColorAssist.overCol(outlineIdle, outlineActive, progress);
        int top = ColorAssist.overCol(ClickGuiTheme.CONTROL_BG, ClickGuiTheme.CONTROL_BG_ACTIVE, progress);
        int bottom = ColorAssist.overCol(ClickGuiTheme.CONTROL_BG_DARK, ClickGuiTheme.CONTROL_BG_ACTIVE_DARK, progress);

        QuickImports.blur.render(ShapeProperties.create(context.getMatrices(), x - 0.35F, y - 0.35F, width + 0.7F, height + 0.7F)
                .round(radius + 0.2F)
                .softness(10F)
                .color(ColorAssist.multAlpha(0xFF060A11, 0.045F + progress * 0.015F))
                .build());

        QuickImports.rectangle.render(ShapeProperties.create(context.getMatrices(), x, y, width, height)
                .round(radius)
                .thickness(1.15F)
                .outlineColor(outline)
                .color(top, top, bottom, bottom)
                .build());
    }

    public static void drawToggle(DrawContext context, float x, float y, float progress) {
        float clamped = MathHelper.clamp(progress, 0F, 1F);
        float trackWidth = ClickGuiTheme.TOGGLE_WIDTH;
        float trackHeight = ClickGuiTheme.TOGGLE_HEIGHT;
        float knobSize = ClickGuiTheme.TOGGLE_KNOB_SIZE;
        float radius = trackHeight / 2F;

        int accentColor = ClickGuiTheme.accent();
        int fillOff = ClickGuiTheme.TOGGLE_BG;
        int fillOn = ColorAssist.multDark(accentColor, 0.7F);
        int fill = ColorAssist.overCol(fillOff, fillOn, clamped);
        int outlineOff = ClickGuiTheme.CONTROL_OUTLINE;
        int outlineOn = ColorAssist.multAlpha(accentColor, 0.85F);
        int outline = ColorAssist.overCol(outlineOff, outlineOn, clamped);
        int knobColor = ColorAssist.overCol(ClickGuiTheme.TOGGLE_KNOB_OFF, ClickGuiTheme.TOGGLE_KNOB_ON, 0.18F + clamped * 0.82F);

        if (clamped > 0.01F) {
            QuickImports.rectangle.render(ShapeProperties.create(context.getMatrices(),
                            x - 1.0F, y - 1.0F, trackWidth + 2.0F, trackHeight + 2.0F)
                    .round(radius + 1.0F)
                    .softness(5.0F)
                    .color(ColorAssist.multAlpha(accentColor, 0.2F * clamped))
                    .build());
        }

        QuickImports.rectangle.render(ShapeProperties.create(context.getMatrices(), x, y, trackWidth, trackHeight)
                .round(radius)
                .thickness(1.05F)
                .outlineColor(outline)
                .color(fill, fill, ColorAssist.multDark(fill, 0.9F), ColorAssist.multDark(fill, 0.9F))
                .build());

        float knobX = x + 1.4F + (trackWidth - knobSize - 2.8F) * clamped;
        float knobY = y + (trackHeight - knobSize) / 2F;

        QuickImports.rectangle.render(ShapeProperties.create(context.getMatrices(), knobX, knobY, knobSize, knobSize)
                .round(knobSize / 2F)
                .color(knobColor, knobColor, ColorAssist.multDark(knobColor, 0.95F), ColorAssist.multDark(knobColor, 0.95F))
                .build());
    }

    public static void drawStateBadge(DrawContext context, float x, float y, float size, float activeProgress) {
        float progress = MathHelper.clamp(activeProgress, 0F, 1F);
        int idle = ClickGuiTheme.CONTROL_OUTLINE;
        int active = ColorAssist.overCol(ClickGuiTheme.CONTROL_OUTLINE, ClickGuiTheme.accentSoft(), 0.55F);
        int outline = ColorAssist.overCol(idle, active, progress);
        int top = ColorAssist.multAlpha(ColorAssist.overCol(ClickGuiTheme.CONTROL_BG, ClickGuiTheme.CONTROL_BG_ACTIVE, progress), 0.9F);
        int bottom = ColorAssist.multAlpha(ColorAssist.overCol(ClickGuiTheme.CONTROL_BG_DARK, ClickGuiTheme.CONTROL_BG_ACTIVE_DARK, progress), 0.9F);

        QuickImports.blur.render(ShapeProperties.create(context.getMatrices(), x - 0.4F, y - 0.4F, size + 0.8F, size + 0.8F)
                .round(4.0F)
                .softness(10F)
                .color(ColorAssist.multAlpha(0xFF060A11, 0.05F + progress * 0.015F))
                .build());

        QuickImports.rectangle.render(ShapeProperties.create(context.getMatrices(), x, y, size, size)
                .round(3.35F)
                .thickness(1.1F)
                .outlineColor(outline)
                .color(top, top, bottom, bottom)
                .build());

        int accentColor = ClickGuiTheme.accent();
        if (progress >= 0.5F) {
            int checkColor = ColorAssist.overCol(0xFFB0B8C8, accentColor, progress);
            Fonts.getSize(13, Fonts.Type.BOLD)
                    .drawCenteredString(context.getMatrices(), "✔", x + size / 2F + 0.55F, y + size / 2F - 1.35F, checkColor);
        } else {
            Fonts.getSize(13, Fonts.Type.BOLD)
                    .drawCenteredString(context.getMatrices(), "✕", x + size / 2F + 0.55F, y + size / 2F - 1.35F, 0xFFF8FBFF);
        }
    }
}
