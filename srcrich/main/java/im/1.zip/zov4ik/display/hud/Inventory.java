package im.zov4ik.display.hud;

import im.zov4ik.utils.client.managers.api.draggable.AbstractDraggable;
import im.zov4ik.utils.display.color.ColorAssist;
import im.zov4ik.utils.display.font.FontRenderer;
import im.zov4ik.utils.display.font.Fonts;
import im.zov4ik.utils.display.geometry.Render2D;
import im.zov4ik.utils.display.shape.ShapeProperties;
import im.zov4ik.utils.interactions.interact.PlayerInteractionHelper;
import net.minecraft.client.gui.DrawContext;
import net.minecraft.client.util.math.MatrixStack;
import net.minecraft.item.ItemStack;

import java.awt.*;
import java.util.ArrayList;
import java.util.List;
import java.util.Objects;
import java.util.stream.IntStream;

public class Inventory extends AbstractDraggable {
    private List<ItemStack> stacks = new ArrayList<>();

    public Inventory() {
        super("Inventory", 385, 40, 122, 58, true);
    }

    @Override
    public boolean visible() {
        return stacks.stream().anyMatch(stack -> !stack.isEmpty()) || PlayerInteractionHelper.isChat(mc.currentScreen);
    }

    @Override
    public void tick() {
        if (PlayerInteractionHelper.nullCheck()) {
            stacks = List.of();
            return;
        }
        stacks = IntStream.range(9, 36).mapToObj(i -> Objects.requireNonNull(mc.player).getInventory().getStack(i)).toList();
    }

    @Override
    public void drawDraggable(DrawContext context) {
        MatrixStack matrix = context.getMatrices();
        FontRenderer titleFont = Fonts.getSize(13, Fonts.Type.SEMI);

        int columns = 9;
        int rows = 3;
        float slotStep = 12.2F;
        float contentX = getX() + 6;
        float contentY = getY() + 17;
        float contentWidth = slotStep * columns - 1.2F;
        float contentHeight = slotStep * rows - 1.2F;
        float panelWidth = contentWidth + 12;
        float panelHeight = contentHeight + 23;

        setWidth((int) Math.ceil(panelWidth));
        setHeight((int) Math.ceil(panelHeight));

        HudTheme.panel(matrix, getX(), getY(), panelWidth, panelHeight, 7.0F);

        float titleWidth = titleFont.getStringWidth("Inventory");
        titleFont.drawString(matrix, "Inventory", getX() + (panelWidth - titleWidth) / 2F, getY() + 8, HudTheme.TEXT);

        for (int i = 1; i < columns; i++) {
            float x = contentX + i * slotStep - 2.1F;
            rectangle.render(ShapeProperties.create(matrix, x, contentY, 0.45F, contentHeight)
                    .round(0F)
                    .color(ColorAssist.multAlpha(HudTheme.TEXT, 0.08F))
                    .build());
        }

        for (int i = 1; i < rows; i++) {
            float y = contentY + i * slotStep - 1.9F;
            rectangle.render(ShapeProperties.create(matrix, contentX, y, contentWidth, 0.45F)
                    .round(0F)
                    .color(ColorAssist.multAlpha(HudTheme.TEXT, 0.08F))
                    .build());
        }

        for (int index = 0; index < stacks.size(); index++) {
            ItemStack stack = stacks.get(index);
            int column = index % columns;
            int row = index / columns;
            float drawX = contentX + column * slotStep - 0.8F;
            float drawY = contentY + row * slotStep - 0.8F;
            Render2D.defaultDrawStack(context, stack, drawX, drawY, false, true, 0.55F);
        }
    }
}
