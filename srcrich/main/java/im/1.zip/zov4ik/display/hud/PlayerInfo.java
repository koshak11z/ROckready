package im.zov4ik.display.hud;

import im.zov4ik.utils.client.managers.api.draggable.AbstractDraggable;
import im.zov4ik.utils.display.font.FontRenderer;
import im.zov4ik.utils.display.font.Fonts;
import net.minecraft.client.gui.DrawContext;
import net.minecraft.client.util.math.MatrixStack;
import net.minecraft.util.math.BlockPos;

import java.util.Objects;

public class PlayerInfo extends AbstractDraggable {
    private float animatedWidth;

    private static final String COMPASS_ICON = "C";
    private static final float HEIGHT = 18.0F;
    private static final float MIN_WIDTH = 100.0F;
    private static final float PADDING_X = 5.0F;
    private static final float ICON_GAP = 4.0F;
    private static final float RADIUS = 4.0F;

    public PlayerInfo() {
        super("Player Info", 4, 120, 100, 18, true);
        this.animatedWidth = 100.0F;
    }

    @Override
    public void drawDraggable(DrawContext context) {
        MatrixStack matrix = context.getMatrices();

        FontRenderer iconFont = Fonts.getSize(20, Fonts.Type.GUIICONS);
        FontRenderer textFont = Fonts.getSize(16, Fonts.Type.BOLD);
        FontRenderer valueFont = Fonts.getSize(16, Fonts.Type.DEFAULT);

        BlockPos blockPos = Objects.requireNonNull(mc.player).getBlockPos();

        String xLabel = "X ";
        String xVal = String.valueOf(blockPos.getX());
        String yLabel = "  Y ";
        String yVal = String.valueOf(blockPos.getY());
        String zLabel = "  Z ";
        String zVal = String.valueOf(blockPos.getZ());

        float iconW = iconFont.getStringWidth(COMPASS_ICON);
        float contentWidth = textFont.getStringWidth(xLabel) + valueFont.getStringWidth(xVal)
                + textFont.getStringWidth(yLabel) + valueFont.getStringWidth(yVal)
                + textFont.getStringWidth(zLabel) + valueFont.getStringWidth(zVal);

        float targetWidth = PADDING_X + iconW + ICON_GAP + contentWidth + PADDING_X;
        targetWidth = Math.max(MIN_WIDTH, targetWidth);

        animateWidth(targetWidth);

        setWidth((int) Math.ceil(animatedWidth));
        setHeight((int) HEIGHT);

        HudTheme.panel(matrix, getX(), getY(), getWidth(), HEIGHT, RADIUS);

        float cx = getX() + PADDING_X;
        float textY = getY() + (HEIGHT - textFont.getStringHeight("X")) / 2.0F;
        float iconY = getY() + (HEIGHT - iconFont.getStringHeight(COMPASS_ICON)) / 2.0F;

        iconFont.drawString(matrix, COMPASS_ICON, cx, iconY, HudTheme.ACCENT);
        cx += iconW + ICON_GAP;

        textFont.drawString(matrix, xLabel, cx, textY, HudTheme.MUTED_TEXT);
        cx += textFont.getStringWidth(xLabel);
        valueFont.drawString(matrix, xVal, cx, textY, HudTheme.TEXT);
        cx += valueFont.getStringWidth(xVal);

        textFont.drawString(matrix, yLabel, cx, textY, HudTheme.MUTED_TEXT);
        cx += textFont.getStringWidth(yLabel);
        valueFont.drawString(matrix, yVal, cx, textY, HudTheme.TEXT);
        cx += valueFont.getStringWidth(yVal);

        textFont.drawString(matrix, zLabel, cx, textY, HudTheme.MUTED_TEXT);
        cx += textFont.getStringWidth(zLabel);
        valueFont.drawString(matrix, zVal, cx, textY, HudTheme.TEXT);
    }

    private void animateWidth(float targetWidth) {
        if (animatedWidth <= 0.0F) animatedWidth = targetWidth;
        animatedWidth += (targetWidth - animatedWidth) * 0.18F;
        if (Math.abs(targetWidth - animatedWidth) < 0.25F) animatedWidth = targetWidth;
    }
}
