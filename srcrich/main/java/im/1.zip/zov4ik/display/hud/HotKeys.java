package im.zov4ik.display.hud;

import im.zov4ik.features.impl.render.Hud;
import im.zov4ik.features.module.Module;
import im.zov4ik.utils.client.chat.StringHelper;
import im.zov4ik.utils.client.managers.api.draggable.AbstractDraggable;
import im.zov4ik.utils.display.color.ColorAssist;
import im.zov4ik.utils.display.font.FontRenderer;
import im.zov4ik.utils.display.font.Fonts;
import im.zov4ik.utils.display.shape.ShapeProperties;
import im.zov4ik.utils.interactions.interact.PlayerInteractionHelper;
import im.zov4ik.utils.math.calc.Calculate;
import im.zov4ik.zov4ik;
import net.minecraft.client.gui.DrawContext;
import net.minecraft.client.util.math.MatrixStack;

import java.util.ArrayList;
import java.util.List;
import java.util.Random;

public class HotKeys extends AbstractDraggable {
    private final List<Module> keysList = new ArrayList<>();
    private long lastKeyChange = 0L;
    private String currentRandomKey = "NONE";
    private float animatedWidth;

    private static final float HEADER_HEIGHT = 20.0F;
    private static final float ROW_HEIGHT = 15.0F;
    private static final float ROW_GAP = 2.0F;
    private static final float MIN_WIDTH = 100.0F;
    private static final float PADDING_X = 6.0F;

    public HotKeys() {
        super("Hot Keys", 300, 40, 100, 34, true);
        this.animatedWidth = 100.0F;
    }

    @Override
    public boolean visible() {
        return Hud.getInstance().interfaceSettings.isSelected("Hot Keys")
                && (!keysList.isEmpty() || PlayerInteractionHelper.isChat(mc.currentScreen));
    }

    @Override
    public void tick() {
        keysList.clear();
        keysList.addAll(zov4ik.getInstance().getModuleProvider().getModules().stream()
                .filter(module -> module.getAnimation().getOutput().floatValue() != 0.0F && module.getKey() != -1)
                .toList());
        if (keysList.isEmpty() && PlayerInteractionHelper.isChat(mc.currentScreen)) {
            long currentTime = System.currentTimeMillis();
            if (currentTime - lastKeyChange >= 1000L) {
                List<String> availableKeys = List.of("A", "B", "C", "D", "E");
                currentRandomKey = availableKeys.get(new Random().nextInt(availableKeys.size()));
                lastKeyChange = currentTime;
            }
        }
    }

    @Override
    public void drawDraggable(DrawContext context) {
        MatrixStack matrix = context.getMatrices();

        FontRenderer headerFont = Fonts.getSize(18, Fonts.Type.BOLD);
        FontRenderer moduleFont = Fonts.getSize(15, Fonts.Type.DEFAULT);
        FontRenderer bindFont = Fonts.getSize(14, Fonts.Type.SEMI);
        FontRenderer headerIconFont = Fonts.getSize(20, Fonts.Type.ICONS);

        boolean drawExample = keysList.isEmpty() && PlayerInteractionHelper.isChat(mc.currentScreen);

        float targetWidth = calculateTargetWidth(headerFont, moduleFont, bindFont, drawExample);
        animateWidth(targetWidth);

        setWidth((int) animatedWidth);
        setHeight((int) calculateHeight(drawExample));

        HudTheme.panel(matrix, getX(), getY(), getWidth(), getHeight(), 5.5F);

        drawHeader(matrix, headerFont, headerIconFont);

        if (drawExample) {
            drawExampleRow(matrix, moduleFont, bindFont);
        } else {
            drawModuleRows(matrix, moduleFont, bindFont);
        }
    }

    private void animateWidth(float targetWidth) {
        if (animatedWidth <= 0.0F) animatedWidth = targetWidth;
        animatedWidth += (targetWidth - animatedWidth) * 0.18F;
        if (Math.abs(targetWidth - animatedWidth) < 0.25F) animatedWidth = targetWidth;
    }

    private float calculateTargetWidth(FontRenderer headerFont, FontRenderer moduleFont, FontRenderer bindFont, boolean drawExample) {
        float maxWidth = MIN_WIDTH;
        float headerWidth = PADDING_X + headerFont.getStringWidth("Hotkeys") + 25.0F;
        maxWidth = Math.max(maxWidth, headerWidth);

        if (drawExample) {
            float rowW = PADDING_X + moduleFont.getStringWidth("Module") + 15.0F + bindFont.getStringWidth(currentRandomKey) + PADDING_X;
            return Math.max(maxWidth, rowW);
        }

        for (Module module : keysList) {
            String bind = formatBind(StringHelper.getBindName(module.getKey()));
            float rowW = PADDING_X + moduleFont.getStringWidth(module.getName()) + 15.0F + bindFont.getStringWidth(bind) + PADDING_X;
            maxWidth = Math.max(maxWidth, rowW);
        }
        return maxWidth;
    }

    private float calculateHeight(boolean drawExample) {
        if (drawExample) return HEADER_HEIGHT + ROW_GAP + ROW_HEIGHT + 4.0F;
        float totalHeight = HEADER_HEIGHT;
        boolean hasVisible = false;
        for (Module module : keysList) {
            float animation = module.getAnimation().getOutput().floatValue();
            if (animation <= 0.0F) continue;
            totalHeight += ROW_GAP + ROW_HEIGHT * animation;
            hasVisible = true;
        }
        if (!hasVisible) totalHeight += ROW_GAP + ROW_HEIGHT;
        return totalHeight + 4.0F;
    }

    private void drawHeader(MatrixStack matrix, FontRenderer headerFont, FontRenderer headerIconFont) {
        headerFont.drawString(matrix, "Hotkeys", getX() + PADDING_X, getY() + 6.0F, HudTheme.TEXT);
        headerIconFont.drawString(matrix, "B", getX() + getWidth() - 18.0F, getY() + 5.0F, HudTheme.ACCENT);
    }

    private void drawExampleRow(MatrixStack matrix, FontRenderer moduleFont, FontRenderer bindFont) {
        drawRow(matrix, moduleFont, bindFont, getY() + HEADER_HEIGHT + ROW_GAP, "Module", formatBind(currentRandomKey));
    }

    private void drawModuleRows(MatrixStack matrix, FontRenderer moduleFont, FontRenderer bindFont) {
        List<Module> visibleModules = keysList.stream()
                .filter(module -> module.getAnimation().getOutput().floatValue() > 0.0F)
                .toList();
        float rowY = getY() + HEADER_HEIGHT + ROW_GAP;
        float centerX = getX() + getWidth() / 2.0F;

        for (Module module : visibleModules) {
            float animation = module.getAnimation().getOutput().floatValue();
            float currentRowY = rowY;
            String bind = formatBind(StringHelper.getBindName(module.getKey()));

            Calculate.scale(matrix, centerX, currentRowY + ROW_HEIGHT / 2.0F, 1.0F, animation, () -> {
                drawRow(matrix, moduleFont, bindFont, currentRowY, module.getName(), bind);
            });
            rowY += ROW_HEIGHT * animation + ROW_GAP;
        }
    }

    private void drawRow(MatrixStack matrix, FontRenderer moduleFont, FontRenderer bindFont,
                         float rowY, String name, String bind) {
        moduleFont.drawString(matrix, name, getX() + PADDING_X, rowY + 4.0F, HudTheme.TEXT);
        float bindWidth = bindFont.getStringWidth(bind);
        bindFont.drawString(matrix, bind, getX() + getWidth() - PADDING_X - bindWidth, rowY + 4.5F, HudTheme.MUTED_TEXT);
    }

    private String formatBind(String bind) {
        if (bind == null || bind.isEmpty()) return "NONE";
        String result = bind.toUpperCase();
        switch (result) {
            case "GRAVE ACCENT" -> result = "GRAVE";
            case "RIGHT SHIFT" -> result = "RSHIFT";
            case "LEFT SHIFT" -> result = "LSHIFT";
            case "RIGHT CONTROL" -> result = "RCTRL";
            case "LEFT CONTROL" -> result = "LCTRL";
            case "RIGHT ALT" -> result = "RALT";
            case "LEFT ALT" -> result = "LALT";
            case "PAGE UP" -> result = "PGUP";
            case "PAGE DOWN" -> result = "PGDN";
            case "BACKSPACE" -> result = "BKSP";
            case "CAPS LOCK" -> result = "CAPS";
            case "SCROLL LOCK" -> result = "SCRL";
            case "NUMPAD ENTER" -> result = "NUMENT";
            case "NUMPAD DECIMAL" -> result = "NUMDEC";
            case "NUMPAD SUBTRACT" -> result = "NUMSUB";
            case "NUMPAD ADD" -> result = "NUMADD";
            case "ENTER" -> result = "ENT";
            case "DELETE" -> result = "DEL";
            case "INSERT" -> result = "INS";
        }
        result = result.replace("NUMPAD ", "NUM").replace("CONTROL", "CTRL");
        if (result.length() > 8) result = result.substring(0, 8);
        return result;
    }
}
