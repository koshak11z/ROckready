package im.zov4ik.display.hud;

import im.zov4ik.features.impl.render.Hud;
import im.zov4ik.features.module.Module;
import im.zov4ik.utils.client.managers.api.draggable.AbstractDraggable;
import im.zov4ik.utils.display.color.ColorAssist;
import im.zov4ik.utils.display.font.FontRenderer;
import im.zov4ik.utils.display.font.Fonts;
import im.zov4ik.utils.display.interfaces.QuickImports;
import im.zov4ik.utils.display.shape.ShapeProperties;
import im.zov4ik.utils.math.calc.Calculate;
import im.zov4ik.zov4ik;
import net.minecraft.client.gui.DrawContext;
import net.minecraft.client.util.math.MatrixStack;

import java.util.ArrayList;
import java.util.Comparator;
import java.util.List;

public class Arraylist extends AbstractDraggable {
    private final List<Module> modules = new ArrayList<>();
    private float animatedWidth;

    private static final float ROW_HEIGHT = 14.0F;
    private static final float ROW_GAP = 2.0F;
    private static final float PAD_X = 6.0F;
    private static final float ACCENT_BAR = 2.0F;
    private static final float RADIUS = 4.0F;
    private static final float MIN_WIDTH = 46.0F;

    public Arraylist() {
        super("Arraylist", 4, 4, 80, 14, true);
        this.animatedWidth = 80.0F;
    }

    @Override
    public boolean visible() {
        return Hud.getInstance().interfaceSettings.isSelected("Arraylist") && !modules.isEmpty();
    }

    @Override
    public void tick() {
        modules.clear();
        modules.addAll(zov4ik.getInstance().getModuleProvider().getModules().stream()
                .filter(Module::isState)
                .toList());
    }

    @Override
    public void drawDraggable(DrawContext context) {
        MatrixStack matrix = context.getMatrices();

        FontRenderer font = Fonts.getSize(18, Fonts.Type.DEFAULT);

        List<Module> sorted = new ArrayList<>(modules);
        sorted.sort(Comparator.comparingDouble(
                (Module module) -> rowWidth(font, module)).reversed());

        float targetWidth = MIN_WIDTH;
        for (Module module : sorted) {
            targetWidth = Math.max(targetWidth, rowWidth(font, module));
        }
        animateWidth(targetWidth);

        setWidth((int) animatedWidth);
        setHeight((int) calculateHeight());

        float left = getX();
        float rowY = getY();

        for (Module module : sorted) {
            float animation = module.getAnimation().getOutput().floatValue();
            if (animation <= 0.0F) {
                continue;
            }

            float pillWidth = rowWidth(font, module);
            float currentY = rowY;

            Calculate.scale(matrix, left, currentY + ROW_HEIGHT / 2.0F, animation, animation, () -> {
                drawPill(matrix, left, currentY, pillWidth, ROW_HEIGHT);

                font.drawString(
                        matrix,
                        module.getVisibleName(),
                        left + PAD_X,
                        currentY + 4.0F,
                        HudTheme.TEXT
                );
            });

            rowY += (ROW_HEIGHT + ROW_GAP) * animation;
        }
    }

    private void animateWidth(float targetWidth) {
        if (animatedWidth <= 0.0F) {
            animatedWidth = targetWidth;
        }
        animatedWidth += (targetWidth - animatedWidth) * 0.18F;
        if (Math.abs(targetWidth - animatedWidth) < 0.25F) {
            animatedWidth = targetWidth;
        }
    }

    private float calculateHeight() {
        float total = 0.0F;
        for (Module module : modules) {
            float animation = module.getAnimation().getOutput().floatValue();
            if (animation <= 0.0F) {
                continue;
            }
            total += (ROW_HEIGHT + ROW_GAP) * animation;
        }
        if (total <= 0.0F) {
            total = ROW_HEIGHT;
        }
        return total;
    }

    private void drawPill(MatrixStack matrix, float x, float y, float w, float h) {
        QuickImports.rectangle.render(ShapeProperties.create(matrix, x - 0.8F, y + 1.0F, w + 1.6F, h + 1.6F)
                .round(RADIUS + 1.0F)
                .softness(5.0F)
                .color(ColorAssist.rgba(0, 0, 0, 115))
                .build());

        QuickImports.rectangle.render(ShapeProperties.create(matrix, x, y, w, h)
                .round(RADIUS)
                .color(ColorAssist.rgba(14, 16, 22, 234))
                .build());
    }

    private float rowWidth(FontRenderer font, Module module) {
        return font.getStringWidth(module.getVisibleName()) + PAD_X * 2.0F;
    }
}
