package im.zov4ik.display.hud;

import im.zov4ik.utils.client.managers.api.draggable.AbstractDraggable;
import im.zov4ik.utils.display.color.ColorAssist;
import im.zov4ik.utils.display.font.FontRenderer;
import im.zov4ik.utils.display.font.Fonts;
import im.zov4ik.utils.display.shape.ShapeProperties;
import im.zov4ik.utils.interactions.interact.PlayerInteractionHelper;
import net.minecraft.client.gui.DrawContext;
import net.minecraft.item.ItemStack;
import net.minecraft.item.Items;

public class TotemCounter extends AbstractDraggable {
    public TotemCounter() {
        super("Totem Counter", 10, 130, 78, 24, true);
    }

    @Override
    public boolean visible() {
        return countTotems() > 0 || PlayerInteractionHelper.isChat(mc.currentScreen);
    }

    @Override
    public void drawDraggable(DrawContext context) {
        int count = countTotems();
        FontRenderer font = Fonts.getSize(13, Fonts.Type.SEMI);
        String text = "Totems " + count;
        int width = (int) Math.ceil(font.getStringWidth(text) + 28);
        setWidth(Math.max(width, 78));
        setHeight(24);
        HudTheme.panel(context.getMatrices(), getX(), getY(), getWidth(), getHeight(), 6.0F);
        context.drawItem(new ItemStack(Items.TOTEM_OF_UNDYING), getX() + 4, getY() + 4);
        font.drawString(context.getMatrices(), text, getX() + 24, getY() + 10, HudTheme.TEXT);
    }

    private int countTotems() {
        if (mc.player == null) {
            return 0;
        }
        int count = 0;
        for (ItemStack stack : mc.player.getInventory().main) {
            if (stack.isOf(Items.TOTEM_OF_UNDYING)) {
                count += stack.getCount();
            }
        }
        ItemStack offhand = mc.player.getOffHandStack();
        if (offhand.isOf(Items.TOTEM_OF_UNDYING)) {
            count += offhand.getCount();
        }
        return count;
    }
}
