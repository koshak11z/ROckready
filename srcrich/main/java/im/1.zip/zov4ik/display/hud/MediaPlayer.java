package im.zov4ik.display.hud;

import dev.redstones.mediaplayerinfo.IMediaSession;
import dev.redstones.mediaplayerinfo.MediaInfo;
import dev.redstones.mediaplayerinfo.MediaPlayerInfo;
import im.zov4ik.zov4ik;
import im.zov4ik.features.impl.render.Hud;
import im.zov4ik.utils.client.Instance;
import im.zov4ik.utils.client.chat.StringHelper;
import im.zov4ik.utils.client.discord.Buffer;
import im.zov4ik.utils.client.managers.api.draggable.AbstractDraggable;
import im.zov4ik.utils.display.color.ColorAssist;
import im.zov4ik.utils.display.font.FontRenderer;
import im.zov4ik.utils.display.font.Fonts;
import im.zov4ik.utils.display.geometry.Render2D;
import im.zov4ik.utils.display.scissor.ScissorAssist;
import im.zov4ik.utils.display.shape.ShapeProperties;
import im.zov4ik.utils.interactions.interact.PlayerInteractionHelper;
import im.zov4ik.utils.math.calc.Calculate;
import im.zov4ik.utils.math.time.StopWatch;
import net.minecraft.client.gui.DrawContext;
import net.minecraft.client.util.math.MatrixStack;
import net.minecraft.util.Identifier;
import net.minecraft.util.math.MathHelper;

import java.awt.*;
import java.util.Arrays;
import java.util.Comparator;
import java.util.concurrent.ExecutorService;
import java.util.concurrent.Executors;

public class MediaPlayer extends AbstractDraggable {

    public static MediaPlayer getInstance() {
        return Instance.getDraggable(MediaPlayer.class);
    }

    private final ExecutorService executorService = Executors.newSingleThreadExecutor();
    private MediaInfo mediaInfo = new MediaInfo("Название Трека", "Артист", new byte[0], 180, 0, false);
    private final Identifier artwork = Identifier.of("textures/music/music.png");
    private final StopWatch lastMedia = new StopWatch();
    public IMediaSession session;
    private float widthDuration;
    private byte[] lastArtworkHash = new byte[0];

    public MediaPlayer() {
        super("Media Player", 10, 120, 115, 40, true);
    }

    @Override
    public boolean visible() {
        return Hud.getInstance().interfaceSettings.isSelected("Media Player")
                && (
                PlayerInteractionHelper.isChat(mc.currentScreen)
                        || session != null
                        || !lastMedia.finished(8000)
        );
    }

    @Override
    public void tick() {
        if (mc.player != null
                && Hud.getInstance().isState()
                && Hud.getInstance().interfaceSettings.isSelected("Media Player")
                && mc.player.age % 10 == 0) {
            executorService.submit(() -> {
                IMediaSession currentSession = session = MediaPlayerInfo.Instance.getMediaSessions().stream().max(Comparator.comparing(s -> s.getMedia().getPlaying())).orElse(null);
                if (currentSession != null) {
                    MediaInfo info = currentSession.getMedia();
                    if (!info.getTitle().isEmpty() || !info.getArtist().isEmpty()) {
                        if (!mediaInfo.getTitle().equals(info.getTitle()) ||
                                !mediaInfo.getArtist().equals(info.getArtist()) ||
                                !Arrays.equals(mediaInfo.getArtworkPng(), info.getArtworkPng()) ||
                                mediaInfo.getDuration() != info.getDuration() ||
                                mediaInfo.getPosition() != info.getPosition() ||
                                mediaInfo.getPlaying() != info.getPlaying()) {
                            if (!Arrays.equals(lastArtworkHash, info.getArtworkPng())) {
                                Buffer.registerTexture(artwork, info.getArtworkPng());
                                lastArtworkHash = info.getArtworkPng().clone();
                            }
                            mediaInfo = info;
                            lastMedia.reset();
                        }
                    }
                }
            });
        }
    }

    private boolean isButtonArea(double mouseX, double mouseY, float buttonX, float buttonSize, float buttonY, float buttonHeight) {
        return mouseX >= buttonX && mouseX <= buttonX + buttonSize && mouseY >= buttonY && mouseY <= buttonY + buttonHeight;
    }

    @Override
    public boolean mouseClicked(double mouseX, double mouseY, int button) {
        if (button == 0 && isHovered(mouseX, mouseY)) {
            FontRenderer icon = Fonts.getSize(17, Fonts.Type.ICONS);
            float playPauseX = (float) (getX() + (getWidth() + 4) / 2) + 4.5f;
            float prevX = (float) (getX() + (getWidth() + 4) / 2) - 4;
            float nextX = (float) (getX() + (getWidth() + 4) / 2) + 14f;
            float y = getY() + 25.5f;
            float buttonSize = icon.getStringWidth("I");
            float buttonHeight = icon.getStringHeight("I");
            if (session != null && isButtonArea(mouseX, mouseY, playPauseX, buttonSize, y, buttonHeight)) {
                executorService.submit(() -> session.playPause());
                return true;
            } else if (session != null && isButtonArea(mouseX, mouseY, prevX, buttonSize, y, buttonHeight)) {
                executorService.submit(() -> session.previous());
                return true;
            } else if (session != null && isButtonArea(mouseX, mouseY, nextX, buttonSize, y, buttonHeight)) {
                executorService.submit(() -> session.next());
                return true;
            } else if (isCanDrag()) {
                return super.mouseClicked(mouseX, mouseY, button);
            }
        }
        return false;
    }

    @Override
    public void drawDraggable(DrawContext context) {
        MatrixStack matrix = context.getMatrices();
        ScissorAssist scissor = zov4ik.getInstance().getScissorManager();
        FontRenderer big = Fonts.getSize(14, Fonts.Type.DEFAULT);
        FontRenderer mini = Fonts.getSize(11, Fonts.Type.DEFAULT);
        FontRenderer icon = Fonts.getSize(17, Fonts.Type.ICONS);

        int sizeArtwork = 32;
        int sizePausePlay = 4;
        int maxDurationWidth = getWidth() - sizeArtwork - 12;
        int duration = (int) mediaInfo.getDuration();
        int position = MathHelper.clamp((int) mediaInfo.getPosition(), 0, duration);

        if (session != null && mediaInfo.getPlaying()) {
            position = Math.min((int) (mediaInfo.getPosition() + lastMedia.elapsedTime() / 1000.0), duration);
        }

        String timeDuration = StringHelper.getDuration(duration);
        String timePosition = StringHelper.getDuration(position);
        widthDuration = MathHelper.clamp(Calculate.interpolateSmooth(1, widthDuration, duration > 0 ? (float) position / duration * maxDurationWidth : 0), 1, maxDurationWidth);


        HudTheme.panel(matrix, getX(), getY(), getWidth(), getHeight(), 5.0F);

        scissor.push(matrix.peek().getPositionMatrix(), getX() + sizeArtwork + 8, getY(), getWidth() - sizeArtwork - 10, getHeight());
        big.drawStringWithScroll(matrix, mediaInfo.getTitle(), getX() + sizeArtwork + 8, getY() + 7, 56, HudTheme.TEXT);
        mini.drawStringWithScroll(matrix, mediaInfo.getArtist(), getX() + sizeArtwork + 8, getY() + 15.5F, 56, HudTheme.muted(0.9F));
        scissor.pop();

        Render2D.drawTexture(context, artwork, getX() + 4, getY() + 4, sizeArtwork, 3, sizeArtwork, sizeArtwork, sizeArtwork, ColorAssist.getRect(1));
        mini.drawString(matrix, timePosition, getX() + 8 + sizeArtwork, getY() + 27, HudTheme.TEXT);
        mini.drawString(matrix, timeDuration, getX() + getWidth() - 4 - mini.getStringWidth(timeDuration), getY() + 27, HudTheme.muted(0.9F));

        rectangle.render(ShapeProperties.create(matrix, getX() + 8 + sizeArtwork, getY() + getHeight() - 8f, maxDurationWidth, 3.5f).round(1.75F).color(ColorAssist.getColor(0, 0, 0, 110)).build());
        HudTheme.accentBar(matrix, getX() + 8 + sizeArtwork, getY() + getHeight() - 8f, maxDurationWidth, 3.5f, maxDurationWidth > 0 ? widthDuration / maxDurationWidth : 0.0F);

        icon.drawString(matrix, (mediaInfo.getPlaying() ? "I" : "H"), (float) (getX() + (getWidth() + 4 - sizePausePlay) / 2) + 4.5f, getY() + 25.5f, HudTheme.TEXT);
        icon.drawString(matrix, "O", (float) (getX() + (getWidth() + 4 - sizePausePlay) / 2) - 4, getY() + 25.5f, HudTheme.muted(0.95F));
        icon.drawString(matrix, "P", (float) (getX() + (getWidth() + 4 - sizePausePlay) / 2) + 14f, getY() + 25.5f, HudTheme.muted(0.95F));
    }
}
