package im.zov4ik.display.hud;

import antidaunleak.api.UserProfile;
import im.zov4ik.utils.client.managers.api.draggable.AbstractDraggable;
import im.zov4ik.utils.display.font.FontRenderer;
import im.zov4ik.utils.display.font.Fonts;
import im.zov4ik.utils.display.shape.ShapeProperties;
import net.minecraft.client.gui.DrawContext;
import net.minecraft.client.util.math.MatrixStack;

import java.awt.*;

public class Watermark extends AbstractDraggable {
    private int fpsCount = 0;
    private float animatedFps = 0.0F;
    private float animatedWidth;

    private static final float HEIGHT = 18.0F;
    private static final float PADDING_X = 5.0F;
    private static final float ICON_GAP = 3.0F;
    private static final float SECTION_GAP = 10.0F;
    private static final float RADIUS = 4.0F;

    private static final String BRAND_LETTER = "Z";
    private static final String PERSON_ICON = "G";
    private static final String PING_ICON = "C";
    private static final String FPS_ICON = "w";
    private static final String CLOCK_ICON = "D";
    private static final String SERVER_ICON = "D";

    public Watermark() {
        super("Watermark", 10, 10, 300, 22, true);
        this.animatedWidth = 300.0F;
    }

    @Override
    public void tick() {
        fpsCount = mc.getCurrentFps();
        if (animatedFps <= 0.0F) {
            animatedFps = fpsCount;
        }
    }

    @Override
    public void drawDraggable(DrawContext context) {
        MatrixStack matrix = context.getMatrices();

        FontRenderer textFont = Fonts.getSize(17, Fonts.Type.DEFAULT);
        FontRenderer boldFont = Fonts.getSize(17, Fonts.Type.BOLD);
        FontRenderer iconFont = Fonts.getSize(20, Fonts.Type.ICONS);
        FontRenderer iconFont2 = Fonts.getSize(20, Fonts.Type.ICONSTYPENEW);

        animateFps();

        String playerName = mc.getSession().getUsername();
        String ping = getPing() + "ms";
        String fps = Math.round(animatedFps) + " FPS";
        String time = java.time.LocalTime.now().format(java.time.format.DateTimeFormatter.ofPattern("HH:mm"));
        String server = mc.getCurrentServerEntry() != null
                ? mc.getCurrentServerEntry().address
                : "Singleplayer";

        float brandW = boldFont.getStringWidth(BRAND_LETTER);

        float nameSection = iconFont.getStringWidth(PERSON_ICON) + ICON_GAP + textFont.getStringWidth(playerName);
        float pingSection = iconFont2.getStringWidth(PING_ICON) + ICON_GAP + textFont.getStringWidth(ping);
        float fpsSection = iconFont2.getStringWidth(FPS_ICON) + ICON_GAP + boldFont.getStringWidth(fps);
        float timeSection = iconFont2.getStringWidth(CLOCK_ICON) + ICON_GAP + textFont.getStringWidth(time);
        float serverSection = iconFont2.getStringWidth(SERVER_ICON) + ICON_GAP + textFont.getStringWidth(server);

        float targetWidth = PADDING_X + brandW + SECTION_GAP
                + nameSection + SECTION_GAP
                + pingSection + SECTION_GAP
                + fpsSection + SECTION_GAP
                + timeSection + SECTION_GAP
                + serverSection + PADDING_X;

        animateWidth(targetWidth);

        setWidth((int) Math.ceil(animatedWidth));
        setHeight((int) HEIGHT);

        HudTheme.panel(matrix, getX(), getY(), getWidth(), HEIGHT, RADIUS);

        float cx = getX() + PADDING_X;
        float centerY = getY() + HEIGHT / 2.0F;

        boldFont.drawString(matrix, BRAND_LETTER, cx, centerY - 3.0F, HudTheme.ACCENT);
        cx += brandW + SECTION_GAP;

        iconFont.drawString(matrix, PERSON_ICON, cx, centerY - 4.5F, HudTheme.ACCENT);
        cx += iconFont.getStringWidth(PERSON_ICON) + ICON_GAP;
        textFont.drawString(matrix, playerName, cx, centerY - 3.0F, HudTheme.TEXT);
        cx += textFont.getStringWidth(playerName) + SECTION_GAP;

        iconFont2.drawString(matrix, PING_ICON, cx, centerY - 3.5F, HudTheme.ACCENT);
        cx += iconFont2.getStringWidth(PING_ICON) + ICON_GAP;
        textFont.drawString(matrix, ping, cx, centerY - 3.0F, HudTheme.TEXT);
        cx += textFont.getStringWidth(ping) + SECTION_GAP;

        iconFont2.drawString(matrix, FPS_ICON, cx, centerY - 3.5F, HudTheme.ACCENT);
        cx += iconFont2.getStringWidth(FPS_ICON) + ICON_GAP;
        boldFont.drawString(matrix, fps, cx, centerY - 3.0F, HudTheme.TEXT);
        cx += boldFont.getStringWidth(fps) + SECTION_GAP;

        iconFont2.drawString(matrix, CLOCK_ICON, cx, centerY - 3.5F, HudTheme.ACCENT);
        cx += iconFont2.getStringWidth(CLOCK_ICON) + ICON_GAP;
        textFont.drawString(matrix, time, cx, centerY - 3.0F, HudTheme.TEXT);
        cx += textFont.getStringWidth(time) + SECTION_GAP;

        iconFont2.drawString(matrix, SERVER_ICON, cx, centerY - 3.5F, HudTheme.ACCENT);
        cx += iconFont2.getStringWidth(SERVER_ICON) + ICON_GAP;
        textFont.drawString(matrix, server, cx, centerY - 3.0F, HudTheme.TEXT);
    }

    private int getPing() {
        if (mc.player == null || mc.getNetworkHandler() == null) return 0;
        var entry = mc.getNetworkHandler().getPlayerListEntry(mc.player.getUuid());
        return entry == null ? 0 : entry.getLatency();
    }

    private void animateFps() {
        animatedFps += (fpsCount - animatedFps) * 0.018F;
        if (Math.abs(fpsCount - animatedFps) < 0.035F) {
            animatedFps = fpsCount;
        }
    }

    private void animateWidth(float targetWidth) {
        if (animatedWidth <= 0.0F) {
            animatedWidth = targetWidth;
        }
        animatedWidth += (targetWidth - animatedWidth) * 0.018F;
        if (Math.abs(targetWidth - animatedWidth) < 0.025F) {
            animatedWidth = targetWidth;
        }
    }
}
