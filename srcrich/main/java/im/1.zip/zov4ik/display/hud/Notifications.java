package im.zov4ik.display.hud;

import im.zov4ik.common.animation.implement.OutBack;
import net.minecraft.client.gui.DrawContext;
import net.minecraft.client.gui.screen.ChatScreen;
import net.minecraft.client.util.math.MatrixStack;
import net.minecraft.component.DataComponentTypes;
import net.minecraft.component.type.ContainerComponent;
import net.minecraft.entity.ItemEntity;
import net.minecraft.item.ItemStack;
import net.minecraft.network.packet.s2c.play.*;
import net.minecraft.sound.SoundEvent;
import net.minecraft.text.MutableText;
import net.minecraft.text.Text;
import net.minecraft.util.Formatting;
import im.zov4ik.utils.client.managers.api.draggable.AbstractDraggable;
import im.zov4ik.common.animation.Animation;
import im.zov4ik.common.animation.Direction;
import im.zov4ik.common.animation.implement.Decelerate;
import im.zov4ik.utils.display.font.FontRenderer;
import im.zov4ik.utils.display.font.Fonts;
import im.zov4ik.utils.display.shape.ShapeProperties;
import im.zov4ik.utils.client.sound.SoundManager;
import im.zov4ik.utils.math.calc.Calculate;
import im.zov4ik.utils.interactions.interact.PlayerInteractionHelper;
import im.zov4ik.utils.client.Instance;
import im.zov4ik.events.container.SetScreenEvent;
import im.zov4ik.events.packet.PacketEvent;
import im.zov4ik.features.impl.render.Hud;

import java.awt.*;
import java.util.ArrayList;
import java.util.Comparator;
import java.util.List;
import java.util.Objects;

public class Notifications extends AbstractDraggable {
    public static Notifications getInstance() {
        return Instance.getDraggable(Notifications.class);
    }

    private final List<Notification> list = new ArrayList<>();
    private final List<Stack> stacks = new ArrayList<>();

    private static final float NOTIF_HEIGHT = 18.0F;
    private static final float DOT_SIZE = 4.0F;
    private static final float PADDING_X = 8.0F;
    private static final float RADIUS = 9.0F;

    public Notifications() {
        super("Notifications", 10, 120, 130, 18, true);
    }

    @Override
    public boolean visible() {
        return Hud.getInstance().interfaceSettings.isSelected(getName())
                && Hud.getInstance().state
                && (!list.isEmpty() || PlayerInteractionHelper.isChat(mc.currentScreen));
    }

    @Override
    public void tick() {
        list.forEach(notif -> {
            if (System.currentTimeMillis() > notif.removeTime || (notif.text.getString().contains("Привет, я уведомление") && !PlayerInteractionHelper.isChat(mc.currentScreen)))
                notif.anim.setDirection(Direction.BACKWARDS);
        });
        list.removeIf(notif -> notif.anim.isFinished(Direction.BACKWARDS));
        while (!stacks.isEmpty()) {
            addTextIfNotEmpty(TypePickUp.INVENTORY, "Предметы подобраны: ");
            addTextIfNotEmpty(TypePickUp.SHULKER_INVENTORY, "Предметы в шалкере: ");
            addTextIfNotEmpty(TypePickUp.SHULKER, "Raised shulker with: ");
        }
    }

    @Override
    public void packet(PacketEvent e) {
        if (!PlayerInteractionHelper.nullCheck()) switch (e.getPacket()) {
            case ItemPickupAnimationS2CPacket item when Hud.getInstance().notificationSettings.isSelected("Item Pick Up") && item.getCollectorEntityId() == Objects.requireNonNull(mc.player).getId() && Objects.requireNonNull(mc.world).getEntityById(item.getEntityId()) instanceof ItemEntity entity -> {
                ItemStack itemStack = entity.getStack();
                ContainerComponent component = itemStack.get(DataComponentTypes.CONTAINER);
                if (component == null) {
                    Text itemText = itemStack.getName();
                    if (itemText.getContent().toString().equals("empty")) {
                        MutableText text = Text.empty().append(itemText);
                        if (itemStack.getCount() > 1)
                            text.append(Formatting.RESET + " [" + Formatting.RED + itemStack.getCount() + Formatting.GRAY + "x" + Formatting.RESET + "]");
                        stacks.add(new Stack(TypePickUp.INVENTORY, text));
                    }
                } else
                    component.stream().filter(s -> s.getName().getContent().toString().equals("empty")).forEach(stack -> {
                        MutableText text = Text.empty().append(stack.getName());
                        if (stack.getCount() > 1)
                            text.append(Formatting.RESET + " [" + Formatting.RED + stack.getCount() + Formatting.GRAY + "x" + Formatting.RESET + "]");
                        stacks.add(new Stack(TypePickUp.SHULKER, text));
                    });
            }
            case ScreenHandlerSlotUpdateS2CPacket slot when Hud.getInstance().notificationSettings.isSelected("Item Pick Up") -> {
                int slotId = slot.getSlot();
                ContainerComponent updatedContainer = slot.getStack().get(DataComponentTypes.CONTAINER);
                if (updatedContainer != null && slotId < Objects.requireNonNull(mc.player).currentScreenHandler.slots.size() && slot.getSyncId() == 0) {
                    ContainerComponent currentContainer = mc.player.currentScreenHandler.getSlot(slotId).getStack().get(DataComponentTypes.CONTAINER);
                    if (currentContainer != null)
                        updatedContainer.stream().filter(stack -> currentContainer.stream().noneMatch(s -> Objects.equals(s.getComponents(), stack.getComponents()) && s.toString().equals(stack.toString()))).forEach(stack -> {
                            MutableText text = Text.empty().append(stack.getName());
                            stacks.add(new Stack(TypePickUp.SHULKER_INVENTORY, text));
                        });
                }
            }
            default -> {
            }
        }
    }

    @Override
    public void setScreen(SetScreenEvent e) {
        if (e.getScreen() instanceof ChatScreen) {
            addList("Привет, я уведомление", 99999999);
        }
    }

    @Override
    public void drawDraggable(DrawContext context) {
        MatrixStack matrix = context.getMatrices();
        FontRenderer font = Fonts.getSize(13, Fonts.Type.DEFAULT);

        /* — calculate max width from content — */
        float maxWidth = 130.0F;
        for (Notification notification : list) {
            float textWidth = font.getStringWidth(notification.text);
            float w = PADDING_X + DOT_SIZE + 6.0F + textWidth + PADDING_X;
            maxWidth = Math.max(maxWidth, w);
        }

        setWidth((int) maxWidth);
        float totalHeight = 0;
        for (Notification notification : list) {
            totalHeight += (NOTIF_HEIGHT + 3) * notification.anim.getOutput().floatValue();
        }
        setHeight((int) Math.max(NOTIF_HEIGHT, totalHeight));

        float offsetY = 0;
        for (Notification notification : list) {
            float anim = notification.anim.getOutput().floatValue();
            float textWidth = font.getStringWidth(notification.text);
            float width = PADDING_X + DOT_SIZE + 6.0F + textWidth + PADDING_X;
            float startY = getY() + offsetY;
            float startX = getX() + (maxWidth - width) / 2.0F;

            Calculate.setAlpha(anim, () -> {
                HudTheme.panel(matrix, startX, startY, width, NOTIF_HEIGHT, RADIUS);

                int dotColor = HudTheme.ACCENT;
                float dotX = startX + PADDING_X;
                float dotY = startY + NOTIF_HEIGHT / 2.0F - DOT_SIZE / 2.0F;
                rectangle.render(ShapeProperties.create(matrix, dotX, dotY, DOT_SIZE, DOT_SIZE)
                        .round(DOT_SIZE / 2.0F)
                        .color(dotColor)
                        .build());

                font.drawText(matrix, notification.text, (int) (dotX + DOT_SIZE + 6.0F), startY + 6.5F);

                if (!notification.isExpired()) {
                    long elapsed = System.currentTimeMillis() - notification.startTime;
                    long totalTime = notification.removeTime - notification.startTime;
                    float progress = 1.0F - Math.min(1.0F, (float) elapsed / totalTime);
                    float progressWidth = (width - 6.0F) * progress;
                    if (progressWidth > 0) {
                        HudTheme.accentBar(matrix, startX + 3.0F, startY + NOTIF_HEIGHT - 2.5F, progressWidth, 1.2F, 1.0F);
                    }
                }
            });
            offsetY += (NOTIF_HEIGHT + 3) * anim;
        }
    }

    private void addTextIfNotEmpty(TypePickUp type, String prefix) {
        MutableText text = Text.empty();
        List<Stack> list = stacks.stream().filter(stack -> stack.type.equals(type)).toList();
        for (int i = 0, size = list.size(); i < size; i++) {
            Stack stack = list.get(i);
            if (stack.type != type) continue;
            text.append(stack.text);
            stacks.remove(stack);
            if (text.getString().length() > 150) break;
            if (i + 1 != size) text.append(" , ");
        }
        if (!text.equals(Text.empty())) addList(Text.empty().append(prefix).append(text), 8000);
    }

    public void addList(String text, long removeTime) {
        addList(text, removeTime, null);
    }

    public void addList(Text text, long removeTime) {
        addList(text, removeTime, null);
    }

    public void addList(String text, long removeTime, SoundEvent sound) {
        addList(Text.empty().append(text), removeTime, sound);
    }

    public void addList(Text text, long removeTime, SoundEvent sound) {
        list.add(new Notification(text, new OutBack().setMs(400).setValue(1), System.currentTimeMillis(), System.currentTimeMillis() + removeTime));
        if (list.size() > 12) list.removeFirst();
        list.sort(Comparator.comparingDouble(notif -> -notif.removeTime));
        if (sound != null) SoundManager.playSound(sound);
    }

    public record Notification(Text text, Animation anim, long startTime, long removeTime) {
        public boolean isExpired() {
            return System.currentTimeMillis() > removeTime;
        }
    }

    public record Stack(TypePickUp type, MutableText text) {
    }

    public enum TypePickUp {
        INVENTORY, SHULKER, SHULKER_INVENTORY
    }
}
