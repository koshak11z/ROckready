package im.zov4ik.display.hud;

import im.zov4ik.utils.interactions.interact.PlayerInteractionHelper;
import im.zov4ik.utils.interactions.inv.InventoryTask;
import net.minecraft.client.gui.DrawContext;
import net.minecraft.client.util.math.MatrixStack;
import net.minecraft.component.DataComponentTypes;
import net.minecraft.component.type.PotionContentsComponent;
import net.minecraft.item.Item;
import net.minecraft.item.ItemStack;
import net.minecraft.item.Items;
import im.zov4ik.utils.client.managers.api.draggable.AbstractDraggable;
import im.zov4ik.features.impl.misc.ServerHelper;
import im.zov4ik.features.impl.render.Hud;
import im.zov4ik.common.animation.Animation;
import im.zov4ik.common.animation.Direction;
import im.zov4ik.common.animation.implement.Decelerate;
import im.zov4ik.utils.display.font.FontRenderer;
import im.zov4ik.utils.display.font.Fonts;
import im.zov4ik.utils.display.shape.ShapeProperties;
import im.zov4ik.utils.display.color.ColorAssist;
import im.zov4ik.utils.client.chat.StringHelper;
import im.zov4ik.utils.display.geometry.Render2D;
import im.zov4ik.utils.math.calc.Calculate;
import im.zov4ik.events.container.SetScreenEvent;
import com.mojang.blaze3d.systems.RenderSystem;
import net.minecraft.client.render.DiffuseLighting;

import java.awt.*;
import java.util.*;
import java.util.List;
import java.util.Optional;
import java.util.stream.Collectors;

/**
 * Binds — restyled to match HotKeys layout (header + vertical rows).
 * Each row: item icon + bind name (left) | key name + count (right)
 * Empty = ✕ marks.
 */
public class Binds extends AbstractDraggable {
    private final ServerHelper serverHelper;
    private final List<BindInfo> binds = new ArrayList<>();
    private final Map<Item, Integer> itemCounts = new HashMap<>();
    private final Set<Item> activeCooldowns = new HashSet<>();
    private final Map<Item, Long> cooldownStartTimes = new HashMap<>();
    private float animatedWidth;
    private long lastBindChange = 0;
    private int currentExampleIndex = 0;

    private static final Item[] EXAMPLE_ITEMS = {Items.ENDER_EYE, Items.SUGAR, Items.DRIED_KELP, Items.NETHERITE_SCRAP};

    private static final float HEADER_HEIGHT = 20.0F;
    private static final float ROW_HEIGHT = 16.0F;
    private static final float ROW_GAP = 2.0F;
    private static final float MIN_WIDTH = 110.0F;
    private static final float PADDING_X = 6.0F;
    private static final float ICON_SIZE = 10.0F;

    private final Animation animation = new Decelerate().setMs(300).setValue(1);

    private static class BindInfo {
        ServerHelper.KeyBind keyBind;
        String displayName;
        int color;
        String searchName;

        BindInfo(ServerHelper.KeyBind keyBind, String displayName, int color, String searchName) {
            this.keyBind = keyBind;
            this.displayName = displayName;
            this.color = color;
            this.searchName = searchName;
        }
    }

    public Binds() {
        super("Binds", 10, 180, 110, 34, true);
        this.serverHelper = ServerHelper.getInstance();
        this.animatedWidth = 110.0F;
        initializeBinds();
    }

    private void initializeBinds() {
        for (ServerHelper.KeyBind keyBind : serverHelper.getKeyBindings()) {
            String name = keyBind.setting().getName();
            String searchName = getSearchNameForBind(name);
            int color = getColorForBind(name);
            binds.add(new BindInfo(keyBind, name, color, searchName));
        }
    }

    private String getSearchNameForBind(String name) {
        return switch (name) {
            case "Зелье отрыжки" -> "отрыжки";
            case "Зелье серной кислоты" -> "серная";
            case "Зелье вспышки" -> "вспышка";
            case "Зелье мочи Флеша" -> "моча флеша";
            case "Зелье победителя" -> "победителя";
            case "Зелье агента" -> "агента";
            case "Зелье медика" -> "медика";
            case "Зелье киллера" -> "киллера";
            default -> null;
        };
    }

    private int getColorForBind(String name) {
        return switch (name) {
            case "Зелье отрыжки" -> 0xFF5D00;
            case "Зелье серной кислоты" -> 0x00C200;
            case "Зелье вспышки" -> 0xFFFFFF;
            case "Зелье мочи Флеша" -> 0x5CF7FF;
            case "Зелье победителя" -> 0x00FF00;
            case "Зелье агента" -> 0xFFFB00;
            case "Зелье медика" -> 0xFF00DE;
            case "Зелье киллера" -> 0xFF0000;
            default -> -1;
        };
    }

    private ItemStack createColoredPotion(Item item, int color) {
        ItemStack stack = new ItemStack(item);
        if (color != -1 && item == Items.SPLASH_POTION) {
            stack.set(DataComponentTypes.POTION_CONTENTS, new PotionContentsComponent(Optional.empty(), Optional.of(color), List.of(), Optional.empty()));
        }
        return stack;
    }

    private int countItemInInventory(Item targetItem, String searchName) {
        if (PlayerInteractionHelper.nullCheck()) return 0;
        int count = 0;
        for (int i = 0; i < mc.player.getInventory().size(); i++) {
            ItemStack itemStack = mc.player.getInventory().getStack(i);
            if (itemStack.isEmpty()) continue;
            if (searchName != null && targetItem == Items.SPLASH_POTION) {
                if (itemStack.getItem() == targetItem && InventoryTask.getCleanName(itemStack.getName()).contains(searchName.toLowerCase())) count += itemStack.getCount();
            } else {
                if (itemStack.getItem() == targetItem) count += itemStack.getCount();
            }
        }
        return count;
    }

    private float getCooldownProgress(Item item) {
        if (PlayerInteractionHelper.nullCheck()) return 0;
        return mc.player.getItemCooldownManager().getCooldownProgress(new ItemStack(item), mc.getRenderTickCounter().getTickDelta(false));
    }

    private boolean isBindActive(BindInfo bind) {
        if (PlayerInteractionHelper.nullCheck() || !bind.keyBind.setting().isVisible()
                || bind.keyBind.setting().getKey() == -1 || bind.keyBind.setting().getKey() == 0) return false;
        return true;
    }

    @Override
    public boolean visible() {
        return Hud.getInstance().interfaceSettings.isSelected("Binds")
                && Hud.getInstance().state
                && !animation.isFinished(Direction.BACKWARDS);
    }

    @Override
    public void tick() {
        if (PlayerInteractionHelper.nullCheck()) { animation.setDirection(Direction.BACKWARDS); return; }
        List<BindInfo> activeBinds = binds.stream().filter(this::isBindActive).toList();
        if (!activeBinds.isEmpty() || PlayerInteractionHelper.isChat(mc.currentScreen)) {
            animation.setDirection(Direction.FORWARDS);
        } else {
            animation.setDirection(Direction.BACKWARDS);
        }

        itemCounts.clear();
        for (BindInfo bind : binds) itemCounts.put(bind.keyBind.item(), countItemInInventory(bind.keyBind.item(), bind.searchName));

        activeCooldowns.clear();
        long currentTime = System.currentTimeMillis();
        for (int i = 0; i < mc.player.getInventory().size(); i++) {
            ItemStack itemStack = mc.player.getInventory().getStack(i);
            if (!itemStack.isEmpty() && mc.player.getItemCooldownManager().isCoolingDown(itemStack)) {
                Item item = itemStack.getItem();
                cooldownStartTimes.putIfAbsent(item, currentTime);
                activeCooldowns.add(item);
            }
        }
        cooldownStartTimes.keySet().removeIf(item -> !activeCooldowns.contains(item));

        if (activeBinds.isEmpty() && PlayerInteractionHelper.isChat(mc.currentScreen)) {
            if (currentTime - lastBindChange >= 1000) {
                currentExampleIndex = (currentExampleIndex + 1) % EXAMPLE_ITEMS.length;
                lastBindChange = currentTime;
            }
        }
    }

    @Override
    public void setScreen(SetScreenEvent e) {
        super.setScreen(e);
        if (PlayerInteractionHelper.nullCheck()) { animation.setDirection(Direction.BACKWARDS); return; }
        if (PlayerInteractionHelper.isChat(e.getScreen())) animation.setDirection(Direction.FORWARDS);
        else {
            if (binds.stream().anyMatch(this::isBindActive)) animation.setDirection(Direction.FORWARDS);
            else animation.setDirection(Direction.BACKWARDS);
        }
    }

    @Override
    public void drawDraggable(DrawContext context) {
        if (!Hud.getInstance().interfaceSettings.isSelected("Binds") || !Hud.getInstance().state) return;
        float animValue = animation.getOutput().floatValue();
        if (animValue <= 0) return;

        MatrixStack matrix = context.getMatrices();
        FontRenderer headerFont = Fonts.getSize(18, Fonts.Type.BOLD);
        FontRenderer nameFont = Fonts.getSize(13, Fonts.Type.DEFAULT);
        FontRenderer keyFont = Fonts.getSize(12, Fonts.Type.SEMI);
        FontRenderer headerIconFont = Fonts.getSize(20, Fonts.Type.ICONS);
        FontRenderer crossFont = Fonts.getSize(11, Fonts.Type.BOLD);
        FontRenderer countFont = Fonts.getSize(10, Fonts.Type.DEFAULT);

        List<BindInfo> activeBinds = binds.stream().filter(this::isBindActive).collect(Collectors.toList());
        boolean drawExample = activeBinds.isEmpty() && PlayerInteractionHelper.isChat(mc.currentScreen);

        float targetWidth = calculateTargetWidth(headerFont, nameFont, keyFont, countFont, activeBinds, drawExample);
        animateWidth(targetWidth);

        setWidth((int) animatedWidth);
        setHeight((int) calculateHeight(activeBinds, drawExample));

        HudTheme.panel(matrix, getX(), getY(), getWidth(), getHeight(), 5.5F);

        /* Header */
        headerFont.drawString(matrix, "Binds", getX() + PADDING_X, getY() + 6.0F, HudTheme.TEXT);
        headerIconFont.drawString(matrix, "B", getX() + getWidth() - 18.0F, getY() + 5.0F, HudTheme.ACCENT);

        if (drawExample) {
            drawExampleRow(context, matrix, nameFont, keyFont, countFont, crossFont);
        } else if (activeBinds.isEmpty()) {
            /* No active binds - show ✕ */
            crossFont.drawString(matrix, "✕", getX() + PADDING_X, getY() + HEADER_HEIGHT + 4.0F, HudTheme.MUTED_TEXT);
        } else {
            drawBindRows(context, matrix, nameFont, keyFont, countFont, crossFont, activeBinds, animValue);
        }
    }

    private void animateWidth(float targetWidth) {
        if (animatedWidth <= 0.0F) animatedWidth = targetWidth;
        animatedWidth += (targetWidth - animatedWidth) * 0.18F;
        if (Math.abs(targetWidth - animatedWidth) < 0.25F) animatedWidth = targetWidth;
    }

    private float calculateTargetWidth(FontRenderer headerFont, FontRenderer nameFont, FontRenderer keyFont, FontRenderer countFont,
                                       List<BindInfo> activeBinds, boolean drawExample) {
        float maxWidth = MIN_WIDTH;
        float headerWidth = PADDING_X + headerFont.getStringWidth("Binds") + 25.0F;
        maxWidth = Math.max(maxWidth, headerWidth);

        if (drawExample) {
            float rowW = PADDING_X + ICON_SIZE + 4.0F + nameFont.getStringWidth("Бинд") + 15.0F + keyFont.getStringWidth("KEY") + 6.0F + countFont.getStringWidth("x64") + PADDING_X;
            return Math.max(maxWidth, rowW);
        }

        for (BindInfo bind : activeBinds) {
            String keyName = StringHelper.getBindName(bind.keyBind.setting().getKey());
            int count = itemCounts.getOrDefault(bind.keyBind.item(), 0);
            String countStr = "x" + count;
            float rowW = PADDING_X + ICON_SIZE + 4.0F + nameFont.getStringWidth(bind.displayName) + 15.0F + keyFont.getStringWidth(keyName) + 6.0F + countFont.getStringWidth(countStr) + PADDING_X;
            maxWidth = Math.max(maxWidth, rowW);
        }
        return maxWidth;
    }

    private float calculateHeight(List<BindInfo> activeBinds, boolean drawExample) {
        if (drawExample) return HEADER_HEIGHT + ROW_GAP + ROW_HEIGHT + 4.0F;
        if (activeBinds.isEmpty()) return HEADER_HEIGHT + ROW_GAP + ROW_HEIGHT + 4.0F;
        return HEADER_HEIGHT + (ROW_GAP + ROW_HEIGHT) * activeBinds.size() + 4.0F;
    }

    private void drawExampleRow(DrawContext context, MatrixStack matrix, FontRenderer nameFont, FontRenderer keyFont, FontRenderer countFont, FontRenderer crossFont) {
        float rowY = getY() + HEADER_HEIGHT + ROW_GAP;

        /* Item icon */
        ItemStack stack = new ItemStack(EXAMPLE_ITEMS[currentExampleIndex]);
        renderItemIcon(context, stack, getX() + PADDING_X, rowY + 1.0F, 0.6F);

        /* Bind name */
        nameFont.drawString(matrix, "Бинд", getX() + PADDING_X + ICON_SIZE + 4.0F, rowY + 4.0F, HudTheme.TEXT);

        /* Key + count right-aligned */
        String countStr = "x64";
        float countWidth = countFont.getStringWidth(countStr);
        countFont.drawString(matrix, countStr, getX() + getWidth() - PADDING_X - countWidth, rowY + 5.0F, HudTheme.MUTED_TEXT);

        String key = "KEY";
        float keyWidth = keyFont.getStringWidth(key);
        keyFont.drawString(matrix, key, getX() + getWidth() - PADDING_X - countWidth - 6.0F - keyWidth, rowY + 4.5F, HudTheme.ACCENT);
    }

    private void drawBindRows(DrawContext context, MatrixStack matrix, FontRenderer nameFont, FontRenderer keyFont,
                              FontRenderer countFont, FontRenderer crossFont, List<BindInfo> activeBinds, float animValue) {
        float rowY = getY() + HEADER_HEIGHT + ROW_GAP;
        float centerX = getX() + getWidth() / 2.0F;

        for (BindInfo bind : activeBinds) {
            float currentRowY = rowY;
            String keyName = StringHelper.getBindName(bind.keyBind.setting().getKey());
            int count = itemCounts.getOrDefault(bind.keyBind.item(), 0);
            boolean isEmpty = count == 0;
            float cooldownProgress = getCooldownProgress(bind.keyBind.item());
            String countStr = isEmpty ? "✕" : "x" + count;

            Calculate.scale(matrix, centerX, currentRowY + ROW_HEIGHT / 2.0F, 1.0F, animValue, () -> {
                /* Item icon */
                ItemStack stack = createColoredPotion(bind.keyBind.item(), bind.color);
                renderItemIcon(context, stack, getX() + PADDING_X, currentRowY + 1.0F, 0.6F);

                /* Bind name */
                int nameColor = isEmpty ? HudTheme.MUTED_TEXT : HudTheme.TEXT;
                nameFont.drawString(matrix, bind.displayName, getX() + PADDING_X + ICON_SIZE + 4.0F, currentRowY + 4.0F, nameColor);

                /* Count right-aligned */
                float countWidth = countFont.getStringWidth(countStr);
                int countColor = isEmpty ? new Color(255, 80, 80).getRGB() : HudTheme.MUTED_TEXT;
                countFont.drawString(matrix, countStr, getX() + getWidth() - PADDING_X - countWidth, currentRowY + 5.0F, countColor);

                /* Key name */
                float keyWidth = keyFont.getStringWidth(keyName);
                int keyColor = isEmpty ? HudTheme.MUTED_TEXT : HudTheme.ACCENT;
                keyFont.drawString(matrix, keyName, getX() + getWidth() - PADDING_X - countWidth - 6.0F - keyWidth, currentRowY + 4.5F, keyColor);

                /* Cooldown bar under row */
                if (cooldownProgress > 0 && !isEmpty) {
                    float barWidth = (getWidth() - 2 * PADDING_X) * cooldownProgress;
                    HudTheme.accentBar(matrix, getX() + PADDING_X, currentRowY + ROW_HEIGHT - 1.5F, barWidth, 1.0F, 1.0F);
                }
            });

            rowY += ROW_HEIGHT + ROW_GAP;
        }
    }

    private void renderItemIcon(DrawContext context, ItemStack stack, float x, float y, float scale) {
        MatrixStack matrices = context.getMatrices();
        matrices.push();
        matrices.translate(x, y, 100);
        matrices.scale(scale, scale, 1);
        RenderSystem.enableBlend();
        RenderSystem.defaultBlendFunc();
        DiffuseLighting.enableGuiDepthLighting();
        context.drawItem(stack, 0, 0);
        DiffuseLighting.disableGuiDepthLighting();
        matrices.pop();
    }
}
