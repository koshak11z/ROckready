package im.zov4ik.display.hud;

import im.zov4ik.common.animation.Animation;
import im.zov4ik.common.animation.Direction;
import im.zov4ik.common.animation.implement.Decelerate;
import im.zov4ik.events.packet.PacketEvent;
import im.zov4ik.features.impl.render.Hud;
import im.zov4ik.utils.client.managers.api.draggable.AbstractDraggable;
import im.zov4ik.utils.display.color.ColorAssist;
import im.zov4ik.utils.display.font.FontRenderer;
import im.zov4ik.utils.display.font.Fonts;
import im.zov4ik.utils.display.geometry.Render2D;
import im.zov4ik.utils.display.shape.ShapeProperties;
import im.zov4ik.utils.interactions.interact.PlayerInteractionHelper;
import im.zov4ik.utils.math.calc.Calculate;
import net.minecraft.client.gui.DrawContext;
import net.minecraft.client.util.math.MatrixStack;
import net.minecraft.entity.effect.StatusEffect;
import net.minecraft.entity.effect.StatusEffectInstance;
import net.minecraft.entity.effect.StatusEffects;
import net.minecraft.network.packet.s2c.play.EntityStatusEffectS2CPacket;
import net.minecraft.network.packet.s2c.play.GameJoinS2CPacket;
import net.minecraft.network.packet.s2c.play.PlayerRespawnS2CPacket;
import net.minecraft.network.packet.s2c.play.RemoveEntityStatusEffectS2CPacket;
import net.minecraft.registry.Registries;
import net.minecraft.registry.entry.RegistryEntry;
import net.minecraft.util.Identifier;

import java.awt.*;
import java.util.ArrayList;
import java.util.List;
import java.util.Objects;
import java.util.Random;

public class Potions extends AbstractDraggable {
    private final List<Potion> list = new ArrayList<>();
    private long lastEffectChange = 0L;
    private RegistryEntry<StatusEffect> currentRandomEffect = StatusEffects.SPEED;
    private float animatedWidth;

    private static final RegistryEntry<StatusEffect>[] NEGATIVE_EFFECTS = new RegistryEntry[]{
            StatusEffects.POISON, StatusEffects.WITHER, StatusEffects.NAUSEA, StatusEffects.BLINDNESS,
            StatusEffects.HUNGER, StatusEffects.SLOWNESS, StatusEffects.MINING_FATIGUE, StatusEffects.INSTANT_DAMAGE,
            StatusEffects.WEAKNESS, StatusEffects.LEVITATION, StatusEffects.UNLUCK, StatusEffects.BAD_OMEN
    };

    private static final float HEADER_HEIGHT = 20.0F;
    private static final float ROW_HEIGHT = 16.0F;
    private static final float ROW_GAP = 2.0F;
    private static final float MIN_WIDTH = 130.0F;
    private static final float ARC_SIZE = 12.0F;
    private static final float ARC_GAP = 5.0F;

    public Potions() {
        super("Potions", 200, 40, 130, 34, true);
        this.animatedWidth = 130.0F;
    }

    @Override
    public boolean visible() {
        return Hud.getInstance().interfaceSettings.isSelected(getName())
                && Hud.getInstance().state
                && (!list.isEmpty() || PlayerInteractionHelper.isChat(mc.currentScreen));
    }

    @Override
    public void tick() {
        list.removeIf(p -> p.anim.isFinished(Direction.BACKWARDS));
        if (!PlayerInteractionHelper.nullCheck()) {
            list.forEach(p -> p.effect.update(mc.player, null));
        }
        if (list.isEmpty() && PlayerInteractionHelper.isChat(mc.currentScreen)) {
            long currentTime = System.currentTimeMillis();
            if (currentTime - lastEffectChange >= 1000L) {
                List<RegistryEntry<StatusEffect>> effects = new ArrayList<>();
                for (Identifier id : Registries.STATUS_EFFECT.getIds()) {
                    Registries.STATUS_EFFECT.getEntry(id).ifPresent(effects::add);
                }
                if (!effects.isEmpty()) {
                    currentRandomEffect = effects.get(new Random().nextInt(effects.size()));
                    lastEffectChange = currentTime;
                }
            }
        }
    }

    @Override
    public void packet(PacketEvent e) {
        switch (e.getPacket()) {
            case EntityStatusEffectS2CPacket effect -> {
                if (!PlayerInteractionHelper.nullCheck() && effect.getEntityId() == Objects.requireNonNull(mc.player).getId()) {
                    RegistryEntry<StatusEffect> effectId = effect.getEffectId();
                    list.stream()
                            .filter(p -> p.effect.getEffectType().getIdAsString().equals(effectId.getIdAsString()))
                            .forEach(p -> p.anim.setDirection(Direction.BACKWARDS));
                    list.add(new Potion(
                            new StatusEffectInstance(effectId, effect.getDuration(), effect.getAmplifier(), effect.isAmbient(), effect.shouldShowParticles(), effect.shouldShowIcon()),
                            new Decelerate().setMs(150).setValue(1.0F)
                    ));
                }
            }
            case RemoveEntityStatusEffectS2CPacket effect -> list.stream()
                    .filter(p -> p.effect.getEffectType().getIdAsString().equals(effect.effect().getIdAsString()))
                    .forEach(p -> p.anim.setDirection(Direction.BACKWARDS));
            case PlayerRespawnS2CPacket p -> list.clear();
            case GameJoinS2CPacket p -> list.clear();
            default -> {
            }
        }
    }

    @Override
    public void drawDraggable(DrawContext context) {
        MatrixStack matrix = context.getMatrices();

        FontRenderer headerFont = Fonts.getSize(18, Fonts.Type.BOLD);
        FontRenderer rowFont = Fonts.getSize(15, Fonts.Type.DEFAULT);
        FontRenderer timeFont = Fonts.getSize(14, Fonts.Type.SEMI);
        FontRenderer headerIconFont = Fonts.getSize(20, Fonts.Type.ICONS);

        boolean drawExample = list.isEmpty() && PlayerInteractionHelper.isChat(mc.currentScreen);

        float targetWidth = calculateTargetWidth(headerFont, rowFont, timeFont, drawExample);
        animateWidth(targetWidth);

        setWidth((int) animatedWidth);
        setHeight((int) calculateHeight(drawExample));

        HudTheme.panel(matrix, getX(), getY(), getWidth(), getHeight(), 5.5F);

        drawHeader(matrix, headerFont, headerIconFont);

        if (drawExample) {
            drawExampleRow(matrix, rowFont, timeFont);
        } else {
            drawPotionRows(matrix, rowFont, timeFont);
        }
    }

    private void animateWidth(float targetWidth) {
        if (animatedWidth <= 0.0F) animatedWidth = targetWidth;
        animatedWidth += (targetWidth - animatedWidth) * 0.18F;
        if (Math.abs(targetWidth - animatedWidth) < 0.25F) animatedWidth = targetWidth;
    }

    private float calculateTargetWidth(FontRenderer headerFont, FontRenderer rowFont, FontRenderer timeFont, boolean drawExample) {
        float maxWidth = MIN_WIDTH;
        float headerWidth = 6.0F + headerFont.getStringWidth(getName()) + 20.0F;
        maxWidth = Math.max(maxWidth, headerWidth);

        if (drawExample) {
            return Math.max(maxWidth, calculateRowWidth(rowFont, timeFont, "Effect", "", "**:**"));
        }

        for (Potion potion : list) {
            float animation = potion.anim.getOutput().floatValue();
            if (animation <= 0.0F) continue;
            StatusEffectInstance effect = potion.effect;
            String name = effect.getEffectType().value().getName().getString();
            String level = effect.getAmplifier() > 0 ? " " + (effect.getAmplifier() + 1) : "";
            String duration = getDuration(effect);
            maxWidth = Math.max(maxWidth, calculateRowWidth(rowFont, timeFont, name, level, duration));
        }
        return maxWidth;
    }

    private float calculateRowWidth(FontRenderer rowFont, FontRenderer timeFont, String name, String level, String duration) {
        return 5.0F + 10.0F + 5.0F + rowFont.getStringWidth(name + level) + 8.0F + ARC_SIZE + ARC_GAP + timeFont.getStringWidth(duration) + 8.0F;
    }

    private float calculateHeight(boolean drawExample) {
        if (drawExample) return HEADER_HEIGHT + ROW_GAP + ROW_HEIGHT + 4.0F;
        float totalHeight = HEADER_HEIGHT;
        boolean hasVisible = false;
        for (Potion potion : list) {
            float animation = potion.anim.getOutput().floatValue();
            if (animation <= 0.0F) continue;
            totalHeight += ROW_GAP + ROW_HEIGHT * animation;
            hasVisible = true;
        }
        if (!hasVisible) totalHeight += ROW_GAP + ROW_HEIGHT;
        return totalHeight + 4.0F;
    }

    private void drawHeader(MatrixStack matrix, FontRenderer headerFont, FontRenderer headerIconFont) {
        headerFont.drawString(matrix, getName(), getX() + 5.0F, getY() + 6.0F, HudTheme.TEXT);
        headerIconFont.drawString(matrix, "C", getX() + getWidth() - 18.0F, getY() + 5.0F, HudTheme.ACCENT);
    }

    private void drawExampleRow(MatrixStack matrix, FontRenderer rowFont, FontRenderer timeFont) {
        drawRow(matrix, rowFont, timeFont, getY() + HEADER_HEIGHT + ROW_GAP,
                currentRandomEffect, "Effect", "", "**:**", false, 255);
    }

    private void drawPotionRows(MatrixStack matrix, FontRenderer rowFont, FontRenderer timeFont) {
        float rowY = getY() + HEADER_HEIGHT + ROW_GAP;
        float centerX = getX() + getWidth() / 2.0F;

        for (Potion potion : list) {
            float animation = potion.anim.getOutput().floatValue();
            if (animation <= 0.0F) continue;
            StatusEffectInstance effect = potion.effect;
            float currentRowY = rowY;
            String name = effect.getEffectType().value().getName().getString();
            String level = effect.getAmplifier() > 0 ? " " + (effect.getAmplifier() + 1) : "";
            String duration = getDuration(effect);
            boolean badEffect = isBadEffect(effect.getEffectType());
            int alpha = getEffectAlpha(effect);

            Calculate.scale(matrix, centerX, currentRowY + ROW_HEIGHT / 2.0F, 1.0F, animation, () -> {
                drawRow(matrix, rowFont, timeFont, currentRowY,
                        effect.getEffectType(), name, level, duration, badEffect, alpha);
            });
            rowY += ROW_HEIGHT * animation + ROW_GAP;
        }
    }

    private void drawRow(MatrixStack matrix, FontRenderer rowFont, FontRenderer timeFont, float rowY,
                         RegistryEntry<StatusEffect> effectType, String name, String level,
                         String duration, boolean badEffect, int alpha) {
        int baseText = ColorAssist.getText();
        int nameColor = badEffect
                ? ColorAssist.rgba(255, 85, 75, alpha)
                : ColorAssist.rgba((baseText >> 16) & 255, (baseText >> 8) & 255, baseText & 255, alpha);
        int accentColor = ColorAssist.multAlpha(HudTheme.ACCENT, alpha / 255.0F);
        int iconColor = badEffect ? nameColor : accentColor;

        float iconX = getX() + 5.0F;
        float textX = iconX + 14.0F;

        Render2D.drawSprite(matrix, mc.getStatusEffectSpriteManager().getSprite(effectType),
                iconX, rowY + 3.0F, 10, 10, iconColor);

        rowFont.drawString(matrix, name, textX, rowY + 4.0F, nameColor);
        if (!level.isEmpty()) {
            rowFont.drawString(matrix, level, textX + rowFont.getStringWidth(name), rowY + 4.0F, nameColor);
        }

        float rightX = getX() + getWidth() - 8.0F;
        float durationWidth = timeFont.getStringWidth(duration);
        timeFont.drawString(matrix, duration, rightX - durationWidth, rowY + 4.5F, HudTheme.MUTED_TEXT);

        float arcCenterX = rightX - durationWidth - ARC_GAP - ARC_SIZE / 2.0F;
        float arcCenterY = rowY + ROW_HEIGHT / 2.0F;
        drawTimerArc(matrix, arcCenterX, arcCenterY, ARC_SIZE, effectType, alpha);
    }

    private void drawTimerArc(MatrixStack matrix, float cx, float cy, float size,
                              RegistryEntry<StatusEffect> effectType, int alpha) {
        float halfSize = size / 2.0F;
        int bgColor = ColorAssist.rgba(60, 65, 80, (int) (alpha * 0.3F));
        int arcColor = ColorAssist.multAlpha(HudTheme.ACCENT, alpha / 255.0F * 0.8F);

        arc.render(ShapeProperties.create(matrix, cx - halfSize, cy - halfSize, size, size)
                .round(0.5F)
                .thickness(0.18F)
                .end(360.0F)
                .color(bgColor)
                .build());

        Potion matchingPotion = null;
        for (Potion p : list) {
            if (p.effect.getEffectType().getIdAsString().equals(effectType.getIdAsString())
                    && p.anim.getOutput().floatValue() > 0.0F) {
                matchingPotion = p;
                break;
            }
        }

        float progress = 360.0F;
        if (matchingPotion != null) {
            StatusEffectInstance eff = matchingPotion.effect;
            if (!eff.isInfinite() && eff.getDuration() > 0) {
                int maxDuration = Math.max(eff.getDuration(), 1200);
                progress = (float) eff.getDuration() / maxDuration * 360.0F;
            }
        }

        if (progress > 0.0F) {
            arc.render(ShapeProperties.create(matrix, cx - halfSize, cy - halfSize, size, size)
                    .round(0.5F)
                    .thickness(0.22F)
                    .end(progress)
                    .color(arcColor, HudTheme.ACCENT, arcColor, HudTheme.ACCENT)
                    .build());
        }
    }

    private int getEffectAlpha(StatusEffectInstance effect) {
        if (effect.getDuration() <= 200 && effect.getDuration() > 0) {
            double output = 0.5 + 0.5 * Math.cos(2 * Math.PI * (System.currentTimeMillis() % 700) / 700.0);
            return (int) (100 + (155 * output));
        }
        if (effect.getDuration() == 0) return 0;
        return 255;
    }

    private String getDuration(StatusEffectInstance pe) {
        int duration = pe.getDuration();
        int mins = duration / 1200;
        return pe.isInfinite() || mins > 60 ? "**:**" : mins + ":" + String.format("%02d", (duration % 1200) / 20);
    }

    private boolean isBadEffect(RegistryEntry<StatusEffect> effect) {
        for (RegistryEntry<StatusEffect> negativeEffect : NEGATIVE_EFFECTS) {
            if (effect == negativeEffect) return true;
        }
        return false;
    }

    private record Potion(StatusEffectInstance effect, Animation anim) {
    }
}
