package im.zov4ik.display.hud;

import im.zov4ik.utils.interactions.interact.PlayerInteractionHelper;
import im.zov4ik.utils.math.time.StopWatch;
import net.minecraft.client.gui.DrawContext;
import net.minecraft.client.render.entity.EntityRenderer;
import net.minecraft.client.render.entity.LivingEntityRenderer;
import net.minecraft.client.render.entity.state.LivingEntityRenderState;
import net.minecraft.client.util.math.MatrixStack;
import net.minecraft.entity.LivingEntity;
import net.minecraft.item.ItemStack;
import net.minecraft.util.Identifier;
import net.minecraft.util.math.MathHelper;
import im.zov4ik.utils.client.managers.api.draggable.AbstractDraggable;
import im.zov4ik.features.impl.combat.Aura;
import im.zov4ik.features.impl.render.Hud;
import im.zov4ik.common.animation.Animation;
import im.zov4ik.common.animation.Direction;
import im.zov4ik.common.animation.implement.Decelerate;
import im.zov4ik.utils.display.font.FontRenderer;
import im.zov4ik.utils.display.font.Fonts;
import im.zov4ik.utils.display.shape.ShapeProperties;
import im.zov4ik.zov4ik;
import im.zov4ik.utils.display.color.ColorAssist;
import im.zov4ik.utils.math.calc.Calculate;
import im.zov4ik.utils.display.geometry.Render2D;
import im.zov4ik.utils.display.scissor.ScissorAssist;
import im.zov4ik.utils.client.packet.network.Network;

import java.awt.*;

public class TargetHud extends AbstractDraggable {
    private final Animation animation = new Decelerate().setMs(650).setValue(1);
    private final Animation faceAlphaAnimation = new Decelerate().setMs(125).setValue(1);
    private final StopWatch stopWatch = new StopWatch();
    private LivingEntity lastTarget;
    private float health;
    private float absorption;

    private static final float PANEL_WIDTH = 140.0F;
    private static final float PANEL_HEIGHT = 44.0F;
    private static final float FACE_SIZE = 24.0F;
    private static final float FACE_PADDING = 6.0F;
    private static final float BAR_HEIGHT = 3.5F;
    private static final float SLOT_SIZE = 8.0F;
    private static final float SLOT_GAP = 1.5F;

    public TargetHud() {
        super("Target Hud", 10, 80, 140, 44, true);
    }

    @Override
    public boolean visible() {
        return scaleAnimation.isDirection(Direction.FORWARDS);
    }

    @Override
    public void tick() {
        LivingEntity auraTarget = Aura.getInstance().getTarget();
        if (auraTarget != null) {
            lastTarget = auraTarget;
            startAnimation();
            faceAlphaAnimation.setDirection(Direction.FORWARDS);
        } else if (PlayerInteractionHelper.isChat(mc.currentScreen)) {
            lastTarget = mc.player;
            startAnimation();
            faceAlphaAnimation.setDirection(Direction.FORWARDS);
        } else if (stopWatch.finished(500)) {
            stopAnimation();
            faceAlphaAnimation.setDirection(Direction.BACKWARDS);
        }
    }

    @Override
    public void drawDraggable(DrawContext context) {
        if (Hud.getInstance().interfaceSettings.isSelected("Target Hud") && Hud.getInstance().state) {
            if (lastTarget != null) {
                MatrixStack matrix = context.getMatrices();
                drawPanel(context, matrix);
            }
        }
    }

    private void drawPanel(DrawContext context, MatrixStack matrix) {
        FontRenderer nameFont = Fonts.getSize(18, Fonts.Type.BOLD);
        FontRenderer hpFont = Fonts.getSize(14, Fonts.Type.BOLD);
        FontRenderer hpIconFont = Fonts.getSize(16, Fonts.Type.ICONS);
        FontRenderer crossFont = Fonts.getSize(11, Fonts.Type.BOLD);

        float hp = PlayerInteractionHelper.getHealth(lastTarget);
        String hpStr = (lastTarget.isInvisible() && !Network.isSpookyTime() && !Network.isCopyTime())
                ? "??" : PlayerInteractionHelper.getHealthString(hp);
        health = MathHelper.clamp(Calculate.interpolateSmooth(1, health, hp / lastTarget.getMaxHealth()), 0, 1);
        float absorptionAmount = lastTarget.getAbsorptionAmount();
        absorption = MathHelper.clamp(Calculate.interpolateSmooth(1, absorption, absorptionAmount / 20.0F), 0, 1);

        String name = lastTarget.getName().getString();
        float nameWidth = Math.min(nameFont.getStringWidth(name), 70.0F);
        float panelW = Math.max(PANEL_WIDTH, FACE_PADDING + FACE_SIZE + 6.0F + nameWidth + 40.0F);

        setWidth((int) panelW);
        setHeight((int) PANEL_HEIGHT);

        HudTheme.panel(matrix, getX(), getY(), getWidth(), PANEL_HEIGHT, 6.0F);

        float contentX = getX() + FACE_PADDING + FACE_SIZE + 6.0F;
        float armorY = getY() + 4.0F;

        /* 6 slots: helmet, chest, legs, boots, mainhand, offhand */
        ItemStack[] slots = new ItemStack[]{
                lastTarget.getEquippedStack(net.minecraft.entity.EquipmentSlot.HEAD),
                lastTarget.getEquippedStack(net.minecraft.entity.EquipmentSlot.CHEST),
                lastTarget.getEquippedStack(net.minecraft.entity.EquipmentSlot.LEGS),
                lastTarget.getEquippedStack(net.minecraft.entity.EquipmentSlot.FEET),
                lastTarget.getMainHandStack(),
                lastTarget.getOffHandStack()
        };

        float itemScale = 0.5F;
        float itemSlotW = 16.0F * itemScale; /* 8px per item */
        float slotStep = itemSlotW + 1.5F;   /* 9.5px between slots */
        float crossW = crossFont.getStringWidth("\u2715");
        float crossH = crossFont.getStringHeight("\u2715");

        float armorX = contentX;
        for (int i = 0; i < 6; i++) {
            if (slots[i] != null && !slots[i].isEmpty()) {
                Render2D.defaultDrawStack(context, slots[i], armorX, armorY, false, false, itemScale);
            } else {
                /* draw ✕ centered in the slot space */
                crossFont.drawString(matrix, "\u2715",
                        armorX + (itemSlotW - crossW) / 2.0F,
                        armorY + (itemSlotW - crossH) / 2.0F,
                        HudTheme.MUTED_TEXT);
            }
            armorX += slotStep;
        }

        /* Name */
        float nameY = getY() + 18.0F;
        if (nameFont.getStringWidth(name) > 70.0F) {
            ScissorAssist scissor = zov4ik.getInstance().getScissorManager();
            scissor.push(matrix.peek().getPositionMatrix(), contentX, getY(), getWidth() - FACE_SIZE - 18.0F, PANEL_HEIGHT);
            nameFont.drawString(matrix, name, contentX, nameY, HudTheme.TEXT);
            scissor.pop();
        } else {
            nameFont.drawString(matrix, name, contentX, nameY, HudTheme.TEXT);
        }

        /* HP bar */
        float barX = contentX;
        float barY = getY() + PANEL_HEIGHT - 11.0F;
        float barWidth = getWidth() - FACE_PADDING - FACE_SIZE - 12.0F - hpFont.getStringWidth(hpStr) - 16.0F;
        barWidth = Math.max(40.0F, barWidth);

        rectangle.render(ShapeProperties.create(matrix, barX, barY, barWidth, BAR_HEIGHT)
                .round(BAR_HEIGHT / 2.0F)
                .color(new Color(0, 0, 0, 110).getRGB())
                .build());
        HudTheme.accentBar(matrix, barX, barY, barWidth, BAR_HEIGHT, health);

        if (absorption > 0.0F && !Network.isFunTime()) {
            rectangle.render(ShapeProperties.create(matrix, barX, barY - 2.0F, barWidth * absorption, 1.2F)
                    .round(0.6F)
                    .softness(3.0F)
                    .color(new Color(255, 196, 45, 190).getRGB())
                    .build());
        }

        /* HP value */
        float hpX = barX + barWidth + 4.0F;
        hpIconFont.drawString(matrix, "C", hpX, barY - 2.5F, HudTheme.ACCENT);
        hpFont.drawString(matrix, hpStr, hpX + hpIconFont.getStringWidth("C") + 2.0F, barY - 0.5F, HudTheme.ACCENT);

        /* Face */
        drawFace(context);
    }

    private void drawFace(DrawContext context) {
        EntityRenderer<? super LivingEntity, ?> baseRenderer = mc.getEntityRenderDispatcher().getRenderer(lastTarget);
        if (!(baseRenderer instanceof LivingEntityRenderer<?, ?, ?>)) {
            return;
        }
        @SuppressWarnings("unchecked")
        LivingEntityRenderer<LivingEntity, LivingEntityRenderState, ?> renderer =
                (LivingEntityRenderer<LivingEntity, LivingEntityRenderState, ?>) baseRenderer;
        LivingEntityRenderState state = renderer.getAndUpdateRenderState(lastTarget, tickCounter.getTickDelta(false));
        Identifier textureLocation = renderer.getTexture(state);
        float alpha = faceAlphaAnimation.getOutput().floatValue();
        Calculate.setAlpha(alpha, () -> {
            Render2D.drawTexture(context, textureLocation,
                    getX() + FACE_PADDING, getY() + (PANEL_HEIGHT - FACE_SIZE) / 2.0F,
                    FACE_SIZE, 4, 8, 8, 64,
                    ColorAssist.getRect(1),
                    ColorAssist.multRed(-1, 1 + lastTarget.hurtTime / 4F));
        });
    }
}
