package im.zov4ik.display.hud;

import im.zov4ik.utils.display.color.ColorAssist;
import im.zov4ik.utils.display.interfaces.QuickImports;
import im.zov4ik.utils.display.shape.ShapeProperties;
import net.minecraft.client.util.math.MatrixStack;

import java.awt.*;

public final class HudTheme {
    public static final int TEXT = new Color(244, 246, 250, 255).getRGB();
    public static final int MUTED_TEXT = new Color(150, 160, 178, 255).getRGB();
    public static final int ACCENT = new Color(124, 92, 255, 255).getRGB();
    public static final int GOOD = new Color(84, 255, 146, 255).getRGB();
    public static final int WARN = new Color(255, 204, 72, 255).getRGB();

    private static final int SHADOW = new Color(0, 0, 0, 135).getRGB();
    private static final int BLUR_TINT = new Color(4, 7, 11, 102).getRGB();
    private static final int FILL_TOP = new Color(16, 20, 30, 94).getRGB();
    private static final int FILL_BOTTOM = new Color(8, 11, 17, 122).getRGB();
    private static final int BORDER = new Color(92, 120, 165, 40).getRGB();

    private HudTheme() {}

    public static int text(float alpha) {
        return ColorAssist.multAlpha(TEXT, alpha);
    }

    public static int muted(float alpha) {
        return ColorAssist.multAlpha(MUTED_TEXT, alpha);
    }

    public static int accent(float alpha) {
        return ColorAssist.multAlpha(ACCENT, alpha);
    }

    public static void panel(MatrixStack matrix, float x, float y, float width, float height, float radius) {
        panel(matrix, x, y, width, height, radius, 1.0F);
    }

    public static void panel(MatrixStack matrix, float x, float y, float width, float height, float radius, float alpha) {
        if (width <= 0.0F || height <= 0.0F || alpha <= 0.0F) {
            return;
        }

        QuickImports.rectangle.render(ShapeProperties.create(matrix, x - 1.0F, y + 1.5F, width + 2.0F, height + 2.4F)
                .round(radius + 3.3F)
                .softness(9.0F)
                .color(ColorAssist.multAlpha(SHADOW, 0.85F * alpha))
                .build());

        QuickImports.blur.render(ShapeProperties.create(matrix, x, y, width, height)
                .round(radius + 2.0F)
                .quality(165.0F)
                .color(ColorAssist.multAlpha(BLUR_TINT, alpha))
                .build());

        QuickImports.rectangle.render(ShapeProperties.create(matrix, x, y, width, height)
                .round(radius + 2.0F)
                .thickness(0.6F)
                .outlineColor(ColorAssist.multAlpha(BORDER, alpha))
                .color(
                        ColorAssist.multAlpha(FILL_TOP, alpha),
                        ColorAssist.multAlpha(FILL_TOP, alpha),
                        ColorAssist.multAlpha(FILL_BOTTOM, alpha),
                        ColorAssist.multAlpha(FILL_BOTTOM, alpha)
                )
                .build());
    }

    public static void panelWithDot(MatrixStack matrix, float x, float y, float width, float height, float radius) {
        panel(matrix, x, y, width, height, radius);
        dot(matrix, x + width - 5.0F, y + 5.0F, 2.6F, ACCENT);
    }

    public static void dangerPanel(MatrixStack matrix, float x, float y, float width, float height, float radius) {
        panel(matrix, x, y, width, height, radius);
        QuickImports.rectangle.render(ShapeProperties.create(matrix, x, y, width, height)
                .round(radius)
                .color(
                        ColorAssist.rgba(96, 16, 22, 70),
                        ColorAssist.rgba(70, 10, 16, 66),
                        ColorAssist.rgba(40, 5, 9, 80),
                        ColorAssist.rgba(60, 8, 13, 74)
                )
                .build());
    }

    public static void dot(MatrixStack matrix, float centerX, float centerY, float size, int color) {
        float radius = size / 2.0F;
        QuickImports.rectangle.render(ShapeProperties.create(matrix, centerX - radius - 1.4F, centerY - radius - 1.4F, size + 2.8F, size + 2.8F)
                .round(radius + 1.0F)
                .softness(4.5F)
                .color(ColorAssist.multAlpha(color, 0.5F))
                .build());
        QuickImports.rectangle.render(ShapeProperties.create(matrix, centerX - radius, centerY - radius, size, size)
                .round(radius * 0.55F)
                .color(color)
                .build());
    }

    public static void accentBar(MatrixStack matrix, float x, float y, float width, float height, float progress) {
        float clamped = Math.max(0.0F, Math.min(1.0F, progress));
        if (width <= 0.0F || height <= 0.0F || clamped <= 0.0F) {
            return;
        }

        float progressWidth = width * clamped;
        QuickImports.rectangle.render(ShapeProperties.create(matrix, x, y, progressWidth, height)
                .round(height / 2.0F)
                .softness(4.0F)
                .color(ColorAssist.multAlpha(ACCENT, 0.3F))
                .build());
        QuickImports.rectangle.render(ShapeProperties.create(matrix, x, y, progressWidth, height)
                .round(height / 2.0F)
                .color(
                        new Color(148, 120, 255, 246).getRGB(),
                        new Color(124, 92, 255, 246).getRGB(),
                        new Color(90, 60, 200, 246).getRGB(),
                        new Color(110, 78, 230, 246).getRGB()
                )
                .build());
    }

    /** Removed — user requested no black bars at top/bottom of screen */
    public static void screenShade(MatrixStack matrix, float width, float height) {
        /* intentionally empty */
    }
}
