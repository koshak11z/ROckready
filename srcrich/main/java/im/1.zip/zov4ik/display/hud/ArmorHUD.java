package im.zov4ik.display.hud;

import im.zov4ik.utils.client.managers.api.draggable.AbstractDraggable;
import im.zov4ik.utils.display.color.ColorAssist;
import im.zov4ik.utils.display.font.FontRenderer;
import im.zov4ik.utils.display.font.Fonts;
import im.zov4ik.utils.display.shape.ShapeProperties;
import im.zov4ik.utils.interactions.interact.PlayerInteractionHelper;
import net.minecraft.client.gui.DrawContext;
import net.minecraft.client.util.math.MatrixStack;
import net.minecraft.entity.EquipmentSlot;
import net.minecraft.item.ItemStack;

public class ArmorHUD extends AbstractDraggable {
    private static final int SLOT_SIZE = 20;

    public ArmorHUD() {
        super("Armor HUD", 400, 40, SLOT_SIZE * 4 + 8, SLOT_SIZE + 8, true);
    }

    @Override
    public boolean visible() {
        return hasArmor() || PlayerInteractionHelper.isChat(mc.currentScreen);
    }

    @Override
    public void drawDraggable(DrawContext context) {
        if (mc.player == null) {
            return;
        }
        MatrixStack matrix = context.getMatrices();
        FontRenderer crossFont = Fonts.getSize(12, Fonts.Type.BOLD);

        setWidth(SLOT_SIZE * 4 + 8);
        setHeight(SLOT_SIZE + 8);
        HudTheme.panel(matrix, getX(), getY(), getWidth(), getHeight(), 6.0F);

        ItemStack[] stacks = new ItemStack[]{
                mc.player.getEquippedStack(EquipmentSlot.HEAD),
                mc.player.getEquippedStack(EquipmentSlot.CHEST),
                mc.player.getEquippedStack(EquipmentSlot.LEGS),
                mc.player.getEquippedStack(EquipmentSlot.FEET)
        };
        for (int i = 0; i < stacks.length; i++) {
            int itemX = getX() + 5 + i * SLOT_SIZE;
            int itemY = getY() + 4;
            if (!stacks[i].isEmpty()) {
                context.drawItem(stacks[i], itemX, itemY);
                context.drawStackOverlay(mc.textRenderer, stacks[i], itemX, itemY);
            } else {
                /* ✕ for empty armor slot */
                float crossW = crossFont.getStringWidth("\u2715");
                float crossH = crossFont.getStringHeight("\u2715");
                crossFont.drawString(matrix, "\u2715",
                        itemX + (SLOT_SIZE - crossW) / 2.0F,
                        itemY + (SLOT_SIZE - crossH) / 2.0F,
                        HudTheme.MUTED_TEXT);
            }
        }
    }

    private boolean hasArmor() {
        if (mc.player == null) {
            return false;
        }
        return !mc.player.getEquippedStack(EquipmentSlot.HEAD).isEmpty()
                || !mc.player.getEquippedStack(EquipmentSlot.CHEST).isEmpty()
                || !mc.player.getEquippedStack(EquipmentSlot.LEGS).isEmpty()
                || !mc.player.getEquippedStack(EquipmentSlot.FEET).isEmpty();
    }
}
