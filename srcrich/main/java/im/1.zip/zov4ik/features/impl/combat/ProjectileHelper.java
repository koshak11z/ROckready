package im.zov4ik.features.impl.combat;

import antidaunleak.api.annotation.Native;
import im.zov4ik.common.repository.friend.Friend;
import im.zov4ik.common.repository.friend.FriendUtils;
import im.zov4ik.features.module.Module;
import im.zov4ik.features.module.ModuleCategory;
import im.zov4ik.features.module.setting.implement.MultiSelectSetting;
import im.zov4ik.features.module.setting.implement.SliderSettings;
import im.zov4ik.utils.features.aura.target.TargetFinder;
import im.zov4ik.utils.features.aura.utils.MathAngle;
import im.zov4ik.utils.features.aura.warp.Turns;
import im.zov4ik.utils.features.aura.warp.TurnsConfig;
import im.zov4ik.utils.features.aura.warp.TurnsConnection;
import im.zov4ik.events.player.RotationUpdateEvent;
import im.zov4ik.utils.client.managers.event.EventHandler;
import im.zov4ik.utils.client.managers.event.types.EventType;
import im.zov4ik.utils.features.aura.warp.TurnsConstructor;
import im.zov4ik.utils.math.calc.Calculate;
import im.zov4ik.utils.math.task.TaskPriority;
import net.minecraft.entity.Entity;
import net.minecraft.entity.LivingEntity;
import net.minecraft.entity.mob.MobEntity;
import net.minecraft.entity.passive.AnimalEntity;
import net.minecraft.entity.player.PlayerEntity;
import net.minecraft.entity.decoration.ArmorStandEntity;
import net.minecraft.item.BowItem;
import net.minecraft.item.CrossbowItem;
import net.minecraft.item.ItemStack;
import net.minecraft.item.TridentItem;
import net.minecraft.util.Hand;
import net.minecraft.util.math.Vec3d;
import net.minecraft.world.World;
import org.lwjgl.system.MathUtil;

import java.util.List;
import java.util.stream.Collectors;
import java.util.stream.StreamSupport;

public class ProjectileHelper extends Module {

    private final SliderSettings searchDistance = new SliderSettings("Дистанция поиска", "Радиус поиска цели вокруг игрока")
            .setValue(16).range(5F, 64F);

    private final MultiSelectSetting targetType = new MultiSelectSetting("Тип таргета", "Фильтрует цели по типу")
            .value("Players", "Mobs", "Animals", "Armor Stand")
            .selected("Players", "Mobs", "Animals");

    private final TargetFinder targetFinder = new TargetFinder();
    private LivingEntity currentTarget;

    public ProjectileHelper() {
        super("ProjectileHelper", "Projectile Helper", ModuleCategory.COMBAT);
        setup(searchDistance, targetType);
    }

    public LivingEntity getTarget(World world, Iterable<Entity> entities) {
        List<Entity> entityList = StreamSupport.stream(entities.spliterator(), false).collect(Collectors.toList());

        List<LivingEntity> validTargets = entityList.stream()
                .filter(e -> e instanceof LivingEntity)
                .map(e -> (LivingEntity) e)
                .filter(this::isValidTarget)
                .collect(Collectors.toList());

        LivingEntity nearestTarget = null;
        double nearestDistance = Double.MAX_VALUE;
        Vec3d playerPos = mc.player.getPos();

        for (LivingEntity target : validTargets) {
            double distance = target.getPos().distanceTo(playerPos);
            if (distance < nearestDistance && distance <= searchDistance.getValue()) {
                nearestDistance = distance;
                nearestTarget = target;
            }

        }

        currentTarget = nearestTarget;
        return currentTarget;
    }

    private boolean isValidTarget(LivingEntity entity) {
        if (entity == null) return false;

       if (entity == mc.player) return false;

        if (!entity.isAlive()) return false;

        if (!targetType.isSelected("Players") && entity instanceof PlayerEntity) return false;
        if (!targetType.isSelected("Mobs") && entity instanceof MobEntity) return false;
        if (!targetType.isSelected("Animals") && entity instanceof AnimalEntity) return false;
        if (!targetType.isSelected("Armor Stand") && entity instanceof ArmorStandEntity) return false;
        return true;
    }


    public Vec3d getPredictedPosition(LivingEntity target, Vec3d shooterPos, float projectileSpeed, float gravity) {
        Vec3d targetPos = target.getPos().add(0, target.getHeight() * 0.5, 0);
        Vec3d targetVelocity = target.getVelocity();
        Vec3d delta = targetPos.subtract(shooterPos);

        double a = projectileSpeed * projectileSpeed - targetVelocity.lengthSquared();
        double b = -2 * delta.dotProduct(targetVelocity);
        double c = -delta.lengthSquared();

        double t;
        double discriminant = b * b - 4 * a * c;
        if (discriminant > 0) {
            double t1 = (-b + Math.sqrt(discriminant)) / (2 * a);
            double t2 = (-b - Math.sqrt(discriminant)) / (2 * a);
            t = Math.max(t1, t2);
        } else {
            t = delta.length() / projectileSpeed;
        }

        Vec3d predicted = targetPos.add(targetVelocity.multiply(t));
        predicted = predicted.add(0, 0.5 * gravity * t * t, 0);

        return predicted;
    }

    private boolean isHoldingProjectile() {
        ItemStack main = mc.player.getMainHandStack();
        return main.getItem() instanceof BowItem || main.getItem() instanceof CrossbowItem || main.getItem() instanceof TridentItem;
    }

    @EventHandler

    public void onRotationUpdate(RotationUpdateEvent e) {
        if (e.getType() != EventType.PRE) return;

        ItemStack stack = mc.player.getMainHandStack();

        boolean holdingBow = stack.getItem() instanceof BowItem;
        boolean holdingCrossbow = stack.getItem() instanceof CrossbowItem && ((CrossbowItem) stack.getItem()).isCharged(stack);
        boolean holdingTrident = stack.getItem() instanceof TridentItem;

        if (!holdingBow && !holdingCrossbow && !holdingTrident) {
            currentTarget = null;
            return;
        }

        if (holdingBow && mc.player.getActiveItem() != stack) {
            currentTarget = null;
            return;
        }

        if (currentTarget != null && !currentTarget.isAlive()) {
            currentTarget = null;
        }

        if (currentTarget == null) {
            currentTarget = getTarget(mc.world, mc.world.getEntities());
            if (currentTarget == mc.player) currentTarget = null;
        }

        if (FriendUtils.isFriend(currentTarget)) currentTarget = null;

        if (currentTarget != null) {
            Vec3d shooterPos = mc.player.getPos()
                    .add(0, mc.player.getEyeHeight(mc.player.getPose()), 0)
                    .add(mc.player.getVelocity());

            float projectileSpeed = 6.0f;
            float gravity = 0.02f;

            Vec3d predictedPos = getPredictedPosition(currentTarget, shooterPos, projectileSpeed, gravity);

            double dx = predictedPos.x - shooterPos.x;
            double dy = predictedPos.y - shooterPos.y;
            double dz = predictedPos.z - shooterPos.z;
            double distanceXZ = Math.sqrt(dx * dx + dz * dz);

            float yaw = (float) Math.toDegrees(Math.atan2(dz, dx)) - 90f + Calculate.getRandom(-1, 1);
            float pitch = (float) -Math.toDegrees(Math.atan2(dy, distanceXZ))+ Calculate.getRandom(-1, 1);


            TurnsConnection.INSTANCE.rotateTo(
                    new Turns(yaw, pitch),
                    TurnsConfig.DEFAULT,
                    im.zov4ik.utils.math.task.TaskPriority.HIGH_IMPORTANCE_1,
                    this
            );
        }
    }
}
