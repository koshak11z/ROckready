package im.zov4ik.features.impl.render;

import com.mojang.blaze3d.platform.GlStateManager;
import com.mojang.blaze3d.systems.RenderSystem;
import lombok.AccessLevel;
import lombok.experimental.FieldDefaults;
import net.minecraft.client.gl.ShaderProgramKeys;
import net.minecraft.client.network.AbstractClientPlayerEntity;
import net.minecraft.client.option.Perspective;
import net.minecraft.client.render.*;
import net.minecraft.client.util.math.MatrixStack;
import net.minecraft.entity.Entity;
import net.minecraft.util.math.RotationAxis;
import org.joml.Matrix4f;
import im.zov4ik.utils.client.managers.event.EventHandler;
import im.zov4ik.features.module.Module;
import im.zov4ik.features.module.ModuleCategory;
import im.zov4ik.features.module.setting.implement.SliderSettings;
import im.zov4ik.common.repository.friend.FriendUtils;
import im.zov4ik.common.animation.Animation;
import im.zov4ik.common.animation.Direction;
import im.zov4ik.common.animation.implement.Decelerate;
import im.zov4ik.utils.display.color.ColorAssist;
import im.zov4ik.utils.display.font.FontRenderer;
import im.zov4ik.utils.display.font.Fonts;
import im.zov4ik.utils.math.calc.Calculate;
import im.zov4ik.events.player.TickEvent;
import im.zov4ik.events.render.DrawEvent;

import java.awt.*;
import java.util.List;

import static net.minecraft.client.render.VertexFormat.DrawMode.TRIANGLES;
import static net.minecraft.client.render.VertexFormats.POSITION_COLOR;

@FieldDefaults(level = AccessLevel.PRIVATE, makeFinal = true)
public class Arrows extends Module {
    Animation radiusAnim = new Decelerate().setMs(150).setValue(6);

    SliderSettings radiusSetting = new SliderSettings("Радиус", "Радиус стрелок")
            .setValue(50).range(30, 100);

    SliderSettings sizeSetting = new SliderSettings("Размер", "Размер стрелок")
            .setValue(10).range(8, 20);

    public Arrows() {
        super("Arrows", "Стрелы", ModuleCategory.RENDER);
        setup(radiusSetting, sizeSetting);
    }

    @EventHandler
    public void onTick(TickEvent e) {
        radiusAnim.setDirection(mc.player.isSprinting() ? Direction.FORWARDS : Direction.BACKWARDS);
    }

    @EventHandler
    public void onDraw(DrawEvent e) {
        MatrixStack matrix = e.getDrawContext().getMatrices();
        FontRenderer distFont = Fonts.getSize(12, Fonts.Type.SEMI);

        List<AbstractClientPlayerEntity> players = mc.world.getPlayers().stream()
                .filter(p -> p != mc.player && p.isAlive() && p.getHealth() > 0)
                .filter(p -> !isGhostPlayer(p))
                .toList();

        float middleW = mc.getWindow().getScaledWidth() / 2f;
        float middleH = mc.getWindow().getScaledHeight() / 2f;
        float radius = radiusSetting.getValue() + radiusAnim.getOutput().floatValue();
        float posY = middleH - radius;
        float size = sizeSetting.getValue();

        if (!mc.options.hudHidden && mc.options.getPerspective().equals(Perspective.FIRST_PERSON) && !players.isEmpty()) {
            for (AbstractClientPlayerEntity player : players) {
                float yaw = getRotations(player) - mc.player.getYaw();
                float distance = (float) mc.player.getPos().distanceTo(player.getPos());
                String distText = Math.round(distance) + "m";
                float distWidth = distFont.getStringWidth(distText);

                int triColor = new Color(220, 220, 220, 200).getRGB();
                int textColor = new Color(200, 200, 200, 180).getRGB();

                matrix.push();
                matrix.translate(middleW, middleH, 0.0F);
                matrix.multiply(RotationAxis.POSITIVE_Z.rotationDegrees(yaw));
                matrix.translate(-middleW, -middleH, 0.0F);

                float triCenterX = middleW;
                float triTopY = posY;
                float triHeight = size * 0.7F;
                float triHalfBase = size * 0.35F;

                RenderSystem.enableBlend();
                RenderSystem.disableCull();
                RenderSystem.disableDepthTest();
                RenderSystem.defaultBlendFunc();
                RenderSystem.setShader(ShaderProgramKeys.POSITION_COLOR);

                BufferBuilder buffer = tessellator.begin(TRIANGLES, POSITION_COLOR);
                Matrix4f mat = matrix.peek().getPositionMatrix();
                buffer.vertex(mat, triCenterX, triTopY, 0).color(triColor);
                buffer.vertex(mat, triCenterX - triHalfBase, triTopY + triHeight, 0).color(triColor);
                buffer.vertex(mat, triCenterX + triHalfBase, triTopY + triHeight, 0).color(triColor);
                BufferRenderer.drawWithGlobalProgram(buffer.end());

                RenderSystem.enableDepthTest();
                RenderSystem.enableCull();
                RenderSystem.disableBlend();

                distFont.drawCenteredString(matrix, distText, triCenterX, triTopY + triHeight + 3.0F, textColor);

                matrix.translate(middleW, middleH, 0.0F);
                matrix.multiply(RotationAxis.POSITIVE_Z.rotationDegrees(-yaw));
                matrix.translate(-middleW, -middleH, 0.0F);
                matrix.pop();
            }
        }
    }

    private boolean isGhostPlayer(AbstractClientPlayerEntity player) {
        if (player.getCustomName() != null) {
            String name = player.getCustomName().getString();
            return name != null && name.startsWith("Ghost_");
        }
        return player.getClass().getSimpleName().equals("OtherClientPlayerEntity")
                && player.getPitch() == -30.0f;
    }

    public static float getRotations(Entity entity) {
        double x = Calculate.interpolate(entity.getX(), entity.getX()) - Calculate.interpolate(mc.player.getX(), mc.player.getX());
        double z = Calculate.interpolate(entity.getZ(), entity.getZ()) - Calculate.interpolate(mc.player.getZ(), mc.player.getZ());
        return (float) -(Math.atan2(x, z) * (180 / Math.PI));
    }
}
